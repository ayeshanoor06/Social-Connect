import * as Notifications from 'expo-notifications';
import { LogBox } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

LogBox.ignoreLogs(['expo-notifications: Android Push', 'expo-notifications']);

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function registerForNotifications() {
  try {
    const { status } = await Notifications.requestPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}

async function getPrefs() {
  try {
    const prefs = await AsyncStorage.getItem('notifPrefs');
    return prefs ? JSON.parse(prefs) : { notifEnabled: true, likeNotif: true, commentNotif: true };
  } catch {
    return { notifEnabled: true, likeNotif: true, commentNotif: true };
  }
}

export async function notifyLiked(postOwnerName, likerName) {
  try {
    const prefs = await getPrefs();
    if (!prefs.notifEnabled || !prefs.likeNotif) return;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '❤️ New Like!',
        body: `${likerName} liked your post`,
        sound: true,
      },
      trigger: null,
    });
  } catch {}
}

export async function notifyUnliked(postOwnerName, likerName) {
  try {
    const prefs = await getPrefs();
    if (!prefs.notifEnabled || !prefs.likeNotif) return;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '💔 Like Removed',
        body: `${likerName} unliked your post`,
        sound: true,
      },
      trigger: null,
    });
  } catch {}
}

export async function notifyCommented(postOwnerName, commenterName, commentText) {
  try {
    const prefs = await getPrefs();
    if (!prefs.notifEnabled || !prefs.commentNotif) return;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '💬 New Comment!',
        body: `${commenterName}: "${commentText.slice(0, 50)}${commentText.length > 50 ? '...' : ''}"`,
        sound: true,
      },
      trigger: null,
    });
  } catch {}
}