import React, { createContext, useState, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const MessageContext = createContext();

export const MessageProvider = ({ children }) => {
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState({});
  const [currentUserId, setCurrentUserId] = useState(null);

  const getChatId = (userId1, userId2) => {
    return [userId1, userId2].sort().join('_');
  };

  const loadConversations = async (userId) => {
    try {
      setCurrentUserId(userId);
      const raw = await AsyncStorage.getItem(`conversations_${userId}`);
      const convos = raw ? JSON.parse(raw) : [];
      setConversations(convos);
    } catch (e) {
      console.log('Load conversations error:', e);
    }
  };

  const loadMessages = async (chatId) => {
    try {
      const raw = await AsyncStorage.getItem(`messages_${chatId}`);
      const msgs = raw ? JSON.parse(raw) : [];
      setMessages(prev => ({ ...prev, [chatId]: msgs }));
      return msgs;
    } catch (e) {
      console.log('Load messages error:', e);
      return [];
    }
  };

  const sendMessage = async (toUserId, toUserName, fromUser, text) => {
    try {
      const chatId = getChatId(fromUser.id, toUserId);

      const newMessage = {
        id: Date.now().toString(),
        chatId,
        senderId: fromUser.id,
        senderName: fromUser.name,
        receiverId: toUserId,
        receiverName: toUserName,
        text: text.trim(),
        createdAt: new Date().toISOString(),
        read: false,
      };

      // Load existing messages
      const raw = await AsyncStorage.getItem(`messages_${chatId}`);
      const existing = raw ? JSON.parse(raw) : [];
      const updated = [...existing, newMessage];

      // Save messages
      await AsyncStorage.setItem(`messages_${chatId}`, JSON.stringify(updated));
      setMessages(prev => ({ ...prev, [chatId]: updated }));

      // Update sender's conversations
      await updateConversation(fromUser.id, {
        chatId,
        otherUserId: toUserId,
        otherUserName: toUserName,
        lastMessage: text.trim(),
        lastMessageTime: newMessage.createdAt,
        unread: 0,
      });

      // Update receiver's conversations
      await updateConversation(toUserId, {
        chatId,
        otherUserId: fromUser.id,
        otherUserName: fromUser.name,
        lastMessage: text.trim(),
        lastMessageTime: newMessage.createdAt,
        unread: 1,
      });

      return newMessage;
    } catch (e) {
      console.log('Send message error:', e);
    }
  };

  const updateConversation = async (userId, convoData) => {
    try {
      const raw = await AsyncStorage.getItem(`conversations_${userId}`);
      const convos = raw ? JSON.parse(raw) : [];
      const existingIdx = convos.findIndex(c => c.chatId === convoData.chatId);

      if (existingIdx >= 0) {
        convos[existingIdx] = {
          ...convos[existingIdx],
          ...convoData,
          unread: userId === currentUserId
            ? 0
            : (convos[existingIdx].unread || 0) + 1,
        };
      } else {
        convos.unshift(convoData);
      }

      // Sort by latest message
      convos.sort((a, b) =>
        new Date(b.lastMessageTime) - new Date(a.lastMessageTime)
      );

      await AsyncStorage.setItem(`conversations_${userId}`, JSON.stringify(convos));

      if (userId === currentUserId) {
        setConversations(convos);
      }
    } catch (e) {
      console.log('Update conversation error:', e);
    }
  };

  const markAsRead = async (chatId) => {
    try {
      const updated = conversations.map(c =>
        c.chatId === chatId ? { ...c, unread: 0 } : c
      );
      setConversations(updated);
      await AsyncStorage.setItem(
        `conversations_${currentUserId}`,
        JSON.stringify(updated)
      );
    } catch (e) {
      console.log('Mark read error:', e);
    }
  };

  const getTotalUnread = () => {
    return conversations.reduce((sum, c) => sum + (c.unread || 0), 0);
  };

  return (
    <MessageContext.Provider value={{
      conversations,
      messages,
      loadConversations,
      loadMessages,
      sendMessage,
      markAsRead,
      getTotalUnread,
      getChatId,
    }}>
      {children}
    </MessageContext.Provider>
  );
};

export const useMessages = () => useContext(MessageContext);