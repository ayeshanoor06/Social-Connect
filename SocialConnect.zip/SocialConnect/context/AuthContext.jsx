import React, { createContext, useState, useContext, useEffect } from 'react';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [appReady, setAppReady] = useState(false);

  // Load saved user on app start
  useEffect(() => {
    const loadUser = async () => {
      try {
        const saved = await AsyncStorage.getItem('currentUser');
        if (saved) {
          setUser(JSON.parse(saved));
        }
      } catch (e) {
        console.log('Load user error:', e);
      } finally {
        setAppReady(true);
      }
    };
    loadUser();
  }, []);

  const saveCurrentUser = async (userData) => {
    try {
      await AsyncStorage.setItem('currentUser', JSON.stringify(userData));
    } catch (e) {
      console.log('Save user error:', e);
    }
  };

  const login = async (email, password) => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));

    try {
      // Get all registered accounts
      const accountsRaw = await AsyncStorage.getItem('accounts');
      const accounts = accountsRaw ? JSON.parse(accountsRaw) : [];

      // Find account with matching email
      const found = accounts.find(
        acc => acc.email.toLowerCase() === email.toLowerCase()
      );

      if (!found) {
        setLoading(false);
        return { success: false, error: 'No account found with this email.' };
      }

      // Check password
      if (found.password !== password) {
        setLoading(false);
        return { success: false, error: 'Incorrect password. Please try again.' };
      }

      // Login success
      const userData = {
        id: found.id,
        name: found.name,
        email: found.email,
        bio: found.bio || '',
        avatar: found.avatar || null,
        followers: found.followers || 0,
        following: found.following || 0,
        posts: found.posts || 0,
      };

      setUser(userData);
      await saveCurrentUser(userData);
      setLoading(false);
      return { success: true };
    } catch (e) {
      setLoading(false);
      return { success: false, error: 'Something went wrong. Please try again.' };
    }
  };

  const signup = async (name, email, password) => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));

    try {
      // Check if email already registered
      const accountsRaw = await AsyncStorage.getItem('accounts');
      const accounts = accountsRaw ? JSON.parse(accountsRaw) : [];

      const exists = accounts.find(
        acc => acc.email.toLowerCase() === email.toLowerCase()
      );

      if (exists) {
        setLoading(false);
        return { success: false, error: 'An account with this email already exists.' };
      }

      // Create new account
      const newUser = {
        id: Date.now().toString(),
        name: name.trim(),
        email: email.toLowerCase(),
        password,
        bio: '',
        avatar: null,
        followers: 0,
        following: 0,
        posts: 0,
      };

      // Save to accounts list
      accounts.push(newUser);
      await AsyncStorage.setItem('accounts', JSON.stringify(accounts));

      // Set as current user (without password)
      const userData = { ...newUser };
      delete userData.password;
      setUser(userData);
      await saveCurrentUser(userData);
      setLoading(false);
      return { success: true };
    } catch (e) {
      setLoading(false);
      return { success: false, error: 'Something went wrong. Please try again.' };
    }
  };

  const updateProfile = async (data) => {
    try {
      const updated = { ...user, ...data };
      setUser(updated);
      await saveCurrentUser(updated);

      // Also update in accounts list
      const accountsRaw = await AsyncStorage.getItem('accounts');
      const accounts = accountsRaw ? JSON.parse(accountsRaw) : [];
      const updatedAccounts = accounts.map(acc =>
        acc.id === user.id ? { ...acc, ...data } : acc
      );
      await AsyncStorage.setItem('accounts', JSON.stringify(updatedAccounts));
    } catch (e) {
      console.log('Update profile error:', e);
    }
  };

  const logout = async () => {
    await AsyncStorage.removeItem('currentUser');
    setUser(null);
    router.replace('/(auth)/login');
  };

  return (
    <AuthContext.Provider value={{
      user, loading, appReady,
      login, signup, logout, updateProfile
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);