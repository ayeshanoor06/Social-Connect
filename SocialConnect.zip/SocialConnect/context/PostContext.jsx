import React, { createContext, useState, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PostContext = createContext();

const SAMPLE_POSTS = [
  {
    id: 'sample1',
    userId: 'sample1',
    userName: 'Social Connect',
    userAvatar: null,
    content: '👋 Welcome to Social Connect! Start by creating your first post and connecting with others.',
    image: null,
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'sample2',
    userId: 'sample2',
    userName: 'Mirha Nasir',
    userAvatar: null,
    content: 'Just launched my first React Native app! So excited to share this journey with everyone 🚀',
    image: null,
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    id: 'sample3',
    userId: 'sample3',
    userName: 'Shahveer Awan',
    userAvatar: null,
    content: 'Beautiful morning for a walk in the park 🌳 Nature always recharges my energy for the week ahead.',
    image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=600',
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 14400000).toISOString(),
  },
  {
    id: 'sample4',
    userId: 'sample4',
    userName: 'Alaya Imran',
    userAvatar: null,
    content: 'Working on a new design system for our team. Clean UI makes such a difference in user experience 🎨',
    image: null,
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 172800000).toISOString(),
  },
];

export const PostProvider = ({ children }) => {
  const [posts, setPosts] = useState(SAMPLE_POSTS);
  const [currentUserId, setCurrentUserId] = useState(null);

  const loadPostsForUser = async (userId) => {
    try {
      setCurrentUserId(userId);
      // Load this user's own posts from storage
      const saved = await AsyncStorage.getItem(`posts_${userId}`);
      const userPosts = saved ? JSON.parse(saved) : [];

      // Merge: user posts on top, then sample posts at bottom
      // Sort by date descending
      const merged = [...userPosts, ...SAMPLE_POSTS].sort(
        (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
      );

      setPosts(merged);
    } catch (e) {
      console.log('Load posts error:', e);
      setPosts(SAMPLE_POSTS);
    }
  };

  const saveUserPosts = async (userId, allPosts) => {
    try {
      // Only save posts that belong to this user, not sample posts
      const userOwnPosts = allPosts.filter(
        p => p.userId === userId
      );
      await AsyncStorage.setItem(
        `posts_${userId}`,
        JSON.stringify(userOwnPosts)
      );
    } catch (e) {
      console.log('Save posts error:', e);
    }
  };

  const addPost = async (newPost, userId) => {
    const updated = [newPost, ...posts];
    setPosts(updated);
    if (userId) {
      await saveUserPosts(userId, updated);
    }
  };

  const toggleLike = async (postId, userId) => {
    const updated = posts.map(post => {
      if (post.id !== postId) return post;
      const liked = post.likes.includes(userId);
      return {
        ...post,
        likes: liked
          ? post.likes.filter(id => id !== userId)
          : [...post.likes, userId],
      };
    });
    setPosts(updated);
    if (currentUserId) {
      await saveUserPosts(currentUserId, updated);
    }
  };

  const addComment = async (postId, comment) => {
    const updated = posts.map(post => {
      if (post.id !== postId) return post;
      return { ...post, comments: [...post.comments, comment] };
    });
    setPosts(updated);
    if (currentUserId) {
      await saveUserPosts(currentUserId, updated);
    }
  };
const deletePost = async (postId, userId) => {
    const updated = posts.filter(p => p.id !== postId);
    setPosts(updated);
    if (userId) {
      await saveUserPosts(userId, updated);
    }
  };

  const editPost = async (postId, newContent, userId) => {
    const updated = posts.map(post => {
      if (post.id !== postId) return post;
      return { ...post, content: newContent, edited: true, editedAt: new Date().toISOString() };
    });
    setPosts(updated);
    if (userId) {
      await saveUserPosts(userId, updated);
    }
  };
  return (
    <PostContext.Provider value={{
      posts,
      loadPostsForUser,
      addPost,
      toggleLike,
      addComment,
      deletePost,
      editPost,
      currentUserId,
    }}>
      {children}
    </PostContext.Provider>
  );
  return (
    <PostContext.Provider value={{
      posts,
      loadPostsForUser,
      addPost,
      toggleLike,
      addComment,
      deletePost,
      currentUserId,
    }}>
      {children}
    </PostContext.Provider>
  );
};
export const usePosts = () => useContext(PostContext);