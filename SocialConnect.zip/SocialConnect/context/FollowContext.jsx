import React, { createContext, useState, useContext, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const FollowContext = createContext();

export const FollowProvider = ({ children }) => {
  // following = list of userIds that current user follows
  const [following, setFollowing] = useState([]);
  // followers = list of userIds that follow current user
  const [followers, setFollowers] = useState([]);
  const [currentUserId, setCurrentUserId] = useState(null);

  const loadFollowData = async (userId) => {
    try {
      setCurrentUserId(userId);
      const followingRaw = await AsyncStorage.getItem(`following_${userId}`);
      const followersRaw = await AsyncStorage.getItem(`followers_${userId}`);
      setFollowing(followingRaw ? JSON.parse(followingRaw) : []);
      setFollowers(followersRaw ? JSON.parse(followersRaw) : []);
    } catch (e) {
      console.log('Load follow error:', e);
    }
  };

  const followUser = async (targetUserId, targetUserName) => {
    try {
      // Add to my following list
      const newFollowing = [...following, targetUserId];
      setFollowing(newFollowing);
      await AsyncStorage.setItem(
        `following_${currentUserId}`,
        JSON.stringify(newFollowing)
      );

      // Add me to target user's followers list
      const targetFollowersRaw = await AsyncStorage.getItem(`followers_${targetUserId}`);
      const targetFollowers = targetFollowersRaw ? JSON.parse(targetFollowersRaw) : [];
      const newTargetFollowers = [...targetFollowers, currentUserId];
      await AsyncStorage.setItem(
        `followers_${targetUserId}`,
        JSON.stringify(newTargetFollowers)
      );

      // Save follow relationship with name for display
      const followingDetails = await AsyncStorage.getItem(`following_details_${currentUserId}`);
      const details = followingDetails ? JSON.parse(followingDetails) : [];
      details.push({ userId: targetUserId, userName: targetUserName });
      await AsyncStorage.setItem(
        `following_details_${currentUserId}`,
        JSON.stringify(details)
      );

      return true;
    } catch (e) {
      console.log('Follow error:', e);
      return false;
    }
  };

  const unfollowUser = async (targetUserId) => {
    try {
      // Remove from my following list
      const newFollowing = following.filter(id => id !== targetUserId);
      setFollowing(newFollowing);
      await AsyncStorage.setItem(
        `following_${currentUserId}`,
        JSON.stringify(newFollowing)
      );

      // Remove me from target user's followers list
      const targetFollowersRaw = await AsyncStorage.getItem(`followers_${targetUserId}`);
      const targetFollowers = targetFollowersRaw ? JSON.parse(targetFollowersRaw) : [];
      const newTargetFollowers = targetFollowers.filter(id => id !== currentUserId);
      await AsyncStorage.setItem(
        `followers_${targetUserId}`,
        JSON.stringify(newTargetFollowers)
      );

      // Remove from following details
      const followingDetails = await AsyncStorage.getItem(`following_details_${currentUserId}`);
      const details = followingDetails ? JSON.parse(followingDetails) : [];
      const newDetails = details.filter(d => d.userId !== targetUserId);
      await AsyncStorage.setItem(
        `following_details_${currentUserId}`,
        JSON.stringify(newDetails)
      );

      return true;
    } catch (e) {
      console.log('Unfollow error:', e);
      return false;
    }
  };

  const isFollowing = (targetUserId) => {
    return following.includes(targetUserId);
  };

  const getFollowingCount = () => following.length;
  const getFollowersCount = () => followers.length;

  return (
    <FollowContext.Provider value={{
      following,
      followers,
      loadFollowData,
      followUser,
      unfollowUser,
      isFollowing,
      getFollowingCount,
      getFollowersCount,
    }}>
      {children}
    </FollowContext.Provider>
  );
};

export const useFollow = () => useContext(FollowContext);