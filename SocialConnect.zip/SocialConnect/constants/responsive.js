import {
  responsiveHeight,
  responsiveWidth,
  responsiveFontSize,
} from 'react-native-responsive-dimensions';

export const rh = responsiveHeight;
export const rw = responsiveWidth;
export const rf = responsiveFontSize;

export const RS = {
  // Font sizes
  xs: rf(1.3),
  sm: rf(1.5),
  md: rf(1.8),
  base: rf(2),
  lg: rf(2.3),
  xl: rf(2.8),
  xxl: rf(3.5),

  // Spacing
  padding: rw(6),
  cardPadding: rw(5),
  radius: rw(3),
  radiusLg: rw(5),

  // Component sizes
  avatarSm: rw(10),
  avatarMd: rw(18),
  avatarLg: rw(22),
  buttonHeight: rh(6.5),
  inputHeight: rh(6),
  tabBarHeight: rh(8),
  headerHeight: rh(7),
};