const Colors = {
  primary: '#6C63FF',
  primaryDark: '#5A52D5',
  primaryLight: '#EAE8FF',
  secondary: '#FF6584',
  background: '#F5F5F5',
  white: '#FFFFFF',
  black: '#1A1A2E',
  gray: '#8892A4',
  lightGray: '#E8ECF4',
  error: '#FF4444',
  success: '#00C48C',
  text: '#1A1A2E',
  subText: '#8892A4',
  border: '#E8ECF4',
  inputBg: '#FFFFFF',
  cardBg: '#FFFFFF',
  tabBar: '#FFFFFF',
};

export default Colors;