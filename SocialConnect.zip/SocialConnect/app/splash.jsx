import {
  View, Text, StyleSheet, Animated, Easing
} from 'react-native';
import { useEffect, useRef } from 'react';
import { router } from 'expo-router';
import Colors from '../constants/colors';
import { RS, rw, rh } from '../constants/responsive';

export default function Splash() {
  // Animation values
  const logoScale = useRef(new Animated.Value(0)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const ringScale1 = useRef(new Animated.Value(0)).current;
  const ringScale2 = useRef(new Animated.Value(0)).current;
  const ringOpacity1 = useRef(new Animated.Value(0.6)).current;
  const ringOpacity2 = useRef(new Animated.Value(0.3)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const textTranslate = useRef(new Animated.Value(30)).current;
  const taglineOpacity = useRef(new Animated.Value(0)).current;
  const dotsOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Sequence of animations
    Animated.sequence([
      // 1. Rings expand
      Animated.parallel([
        Animated.timing(ringScale1, {
          toValue: 1, duration: 600,
          easing: Easing.out(Easing.back(1.5)),
          useNativeDriver: true,
        }),
        Animated.timing(ringOpacity1, {
          toValue: 0.15, duration: 600,
          useNativeDriver: true,
        }),
      ]),

      // 2. Logo pops in
      Animated.parallel([
        Animated.spring(logoScale, {
          toValue: 1, speed: 8, bounciness: 18,
          useNativeDriver: true,
        }),
        Animated.timing(logoOpacity, {
          toValue: 1, duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(ringScale2, {
          toValue: 1, duration: 500,
          easing: Easing.out(Easing.back(1.2)),
          useNativeDriver: true,
        }),
        Animated.timing(ringOpacity2, {
          toValue: 0.1, duration: 500,
          useNativeDriver: true,
        }),
      ]),

      // 3. App name slides up
      Animated.parallel([
        Animated.timing(textOpacity, {
          toValue: 1, duration: 400,
          useNativeDriver: true,
        }),
        Animated.timing(textTranslate, {
          toValue: 0, duration: 400,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
      ]),

      // 4. Tagline fades in
      Animated.timing(taglineOpacity, {
        toValue: 1, duration: 400,
        useNativeDriver: true,
      }),

      // 5. Dots appear
      Animated.timing(dotsOpacity, {
        toValue: 1, duration: 300,
        useNativeDriver: true,
      }),

    ]).start();

    // Navigate after 2.5 seconds
    const timer = setTimeout(() => {
      router.replace('/(auth)/login');
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={s.container}>

      {/* Background decorative circles */}
      <Animated.View style={[s.bgCircle1, {
        transform: [{ scale: ringScale1 }],
        opacity: ringOpacity1,
      }]} />
      <Animated.View style={[s.bgCircle2, {
        transform: [{ scale: ringScale2 }],
        opacity: ringOpacity2,
      }]} />
      <Animated.View style={[s.bgCircle3]} />

      {/* Logo */}
      <Animated.View style={[s.logoWrap, {
        transform: [{ scale: logoScale }],
        opacity: logoOpacity,
      }]}>
        {/* Outer glow ring */}
        <View style={s.glowRing}>
          {/* Inner logo */}
          <View style={s.logo}>
            {/* SC Letters */}
            <Text style={s.logoLetters}>SC</Text>
          </View>
        </View>

        {/* Floating dots around logo */}
        <View style={[s.floatDot, s.floatDot1]} />
        <View style={[s.floatDot, s.floatDot2]} />
        <View style={[s.floatDot, s.floatDot3]} />
        <View style={[s.floatDot, s.floatDot4]} />
      </Animated.View>

      {/* App Name */}
      <Animated.View style={{
        opacity: textOpacity,
        transform: [{ translateY: textTranslate }],
        alignItems: 'center',
      }}>
        <Text style={s.appName}>Social Connect</Text>
      </Animated.View>

      {/* Tagline */}
      <Animated.View style={{ opacity: taglineOpacity, alignItems: 'center' }}>
        <Text style={s.tagline}>Connect • Share • Inspire</Text>
      </Animated.View>

      {/* Bottom loading dots */}
      <Animated.View style={[s.dotsRow, { opacity: dotsOpacity }]}>
        <View style={[s.dot, { backgroundColor: Colors.primary }]} />
        <View style={[s.dot, { backgroundColor: Colors.secondary }]} />
        <View style={[s.dot, { backgroundColor: Colors.teal }]} />
      </Animated.View>

    </View>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Background decorative circles
  bgCircle1: {
    position: 'absolute',
    width: rw(120),
    height: rw(120),
    borderRadius: rw(60),
    backgroundColor: Colors.white,
    top: -rw(20),
    right: -rw(20),
  },
  bgCircle2: {
    position: 'absolute',
    width: rw(80),
    height: rw(80),
    borderRadius: rw(40),
    backgroundColor: Colors.secondary,
    bottom: -rw(10),
    left: -rw(10),
  },
  bgCircle3: {
    position: 'absolute',
    width: rw(40),
    height: rw(40),
    borderRadius: rw(20),
    backgroundColor: Colors.teal,
    opacity: 0.3,
    bottom: rh(15),
    right: rw(8),
  },

  // Logo
  logoWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: rh(4),
    position: 'relative',
  },
  glowRing: {
    width: rw(38),
    height: rw(38),
    borderRadius: rw(19),
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  logo: {
    width: rw(28),
    height: rw(28),
    borderRadius: rw(14),
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
  },
  logoLetters: {
    fontSize: RS.xxl,
    fontWeight: '900',
    color: Colors.primary,
    letterSpacing: 2,
  },

  // Floating dots around logo
  floatDot: {
    position: 'absolute',
    width: rw(3),
    height: rw(3),
    borderRadius: rw(1.5),
    backgroundColor: Colors.white,
    opacity: 0.7,
  },
  floatDot1: { top: 0, right: rw(2) },
  floatDot2: { bottom: rw(1), left: rw(3) },
  floatDot3: { top: rw(4), left: 0 },
  floatDot4: { bottom: 0, right: rw(5) },

  // Text
  appName: {
    fontSize: RS.xxl + 4,
    fontWeight: '900',
    color: Colors.white,
    letterSpacing: 1.5,
    marginBottom: rh(1),
    textShadowColor: 'rgba(0,0,0,0.2)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  tagline: {
    fontSize: RS.md,
    color: 'rgba(255,255,255,0.75)',
    letterSpacing: 2,
    fontWeight: '500',
    marginBottom: rh(8),
  },

  // Loading dots
  dotsRow: {
    position: 'absolute',
    bottom: rh(8),
    flexDirection: 'row',
    gap: rw(3),
  },
  dot: {
    width: rw(2.5),
    height: rw(2.5),
    borderRadius: rw(1.5),
    opacity: 0.9,
  },
});