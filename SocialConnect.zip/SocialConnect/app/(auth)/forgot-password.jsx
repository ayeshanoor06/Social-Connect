import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform
} from 'react-native';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { router } from 'expo-router';
import { useState } from 'react';
import Colors from '../../constants/colors';
import { SIZES, SHADOWS } from '../../constants/theme';

const schema = Yup.object({
  email: Yup.string().email('Invalid email').required('Email is required'),
});

export default function ForgotPassword() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const formik = useFormik({
    initialValues: { email: '' },
    validationSchema: schema,
    onSubmit: async () => {
      setLoading(true);
      await new Promise(r => setTimeout(r, 1500));
      setLoading(false);
      setSent(true);
    },
  });

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={s.container}>

        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}>
          <Text style={s.backTxt}>← Back to Login</Text>
        </TouchableOpacity>

        <View style={s.iconBox}>
          <Text style={{ fontSize: 36 }}>🔐</Text>
        </View>

        <Text style={s.title}>Forgot Password?</Text>
        <Text style={s.subtitle}>No worries! Enter your email and we'll send you a reset link.</Text>

        {sent ? (
          <View style={s.successCard}>
            <Text style={{ fontSize: 48, marginBottom: 12 }}>✅</Text>
            <Text style={s.successTitle}>Email Sent!</Text>
            <Text style={s.successSub}>Check your inbox for the password reset link.</Text>
            <TouchableOpacity style={s.btn} onPress={() => router.replace('/(auth)/login')}>
              <Text style={s.btnText}>Back to Login</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={s.card}>
            <Text style={s.label}>Email Address</Text>
            <TextInput
              style={[s.input, formik.touched.email && formik.errors.email && s.inputErr]}
              placeholder="you@email.com"
              placeholderTextColor={Colors.gray}
              keyboardType="email-address"
              autoCapitalize="none"
              value={formik.values.email}
              onChangeText={formik.handleChange('email')}
              onBlur={formik.handleBlur('email')}
            />
            {formik.touched.email && formik.errors.email
              ? <Text style={s.errTxt}>{formik.errors.email}</Text>
              : null
            }
            <TouchableOpacity
              style={[s.btn, loading && { opacity: 0.75 }]}
              onPress={formik.handleSubmit}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading
                ? <ActivityIndicator color={Colors.white} />
                : <Text style={s.btnText}>Send Reset Link</Text>
              }
            </TouchableOpacity>
          </View>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: Colors.background,
    paddingHorizontal: 24, paddingTop: 60,
  },
  backBtn: { marginBottom: 32 },
  backTxt: { color: Colors.primary, fontSize: SIZES.md, fontWeight: '600' },
  iconBox: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.primaryLight,
    justifyContent: 'center', alignItems: 'center', alignSelf: 'center', marginBottom: 24,
  },
  title: { fontSize: SIZES.xxl, fontWeight: '700', color: Colors.text, textAlign: 'center', marginBottom: 8 },
  subtitle: { fontSize: SIZES.md, color: Colors.subText, textAlign: 'center', lineHeight: 22, marginBottom: 32 },
  card: {
    backgroundColor: Colors.cardBg, borderRadius: SIZES.radiusLg,
    padding: 24, ...SHADOWS.card,
  },
  label: { fontSize: SIZES.sm, fontWeight: '600', color: Colors.text, marginBottom: 8 },
  input: {
    backgroundColor: Colors.inputBg, borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: SIZES.radius, paddingHorizontal: 16,
    paddingVertical: 13, fontSize: SIZES.base, color: Colors.text, marginBottom: 8,
  },
  inputErr: { borderColor: Colors.error },
  errTxt: { color: Colors.error, fontSize: SIZES.xs, marginBottom: 8 },
  btn: {
    backgroundColor: Colors.primary, borderRadius: SIZES.radius,
    paddingVertical: 15, alignItems: 'center', marginTop: 12, ...SHADOWS.button,
  },
  btnText: { color: Colors.white, fontSize: SIZES.base, fontWeight: '700' },
  successCard: {
    backgroundColor: Colors.cardBg, borderRadius: SIZES.radiusLg,
    padding: 32, alignItems: 'center', ...SHADOWS.card,
  },
  successTitle: { fontSize: SIZES.xl, fontWeight: '700', color: Colors.success, marginBottom: 8 },
  successSub: { fontSize: SIZES.md, color: Colors.subText, textAlign: 'center', marginBottom: 24 },
});