import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, ActivityIndicator,
  KeyboardAvoidingView, Platform, Alert
} from 'react-native';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Link, router } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import Colors from '../../constants/colors';
import { SHADOWS } from '../../constants/theme';
import { RS, rw, rh } from '../../constants/responsive';

const schema = Yup.object({
  name: Yup.string().min(2, 'Too short').required('Name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string().min(6, 'At least 6 characters').required('Required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password')], 'Passwords do not match')
    .required('Please confirm'),
});

export default function Signup() {
  const { signup, loading } = useAuth();

  const formik = useFormik({
    initialValues: { name: '', email: '', password: '', confirmPassword: '' },
    validationSchema: schema,
    onSubmit: async (v) => {
  const result = await signup(v.name, v.email, v.password);
  if (result.success) {
    router.replace('/(tabs)/home');
  } else {
    Alert.alert('Sign Up Failed', result.error);
  }
},
  });

  const field = (name, label, opts = {}) => (
    <View style={{ marginBottom: rh(2) }}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        style={[s.input, formik.touched[name] && formik.errors[name] && s.inputErr]}
        placeholder={opts.placeholder || ''}
        placeholderTextColor={Colors.gray}
        secureTextEntry={!!opts.secure}
        autoCapitalize={opts.cap || 'none'}
        keyboardType={opts.keyboard || 'default'}
        value={formik.values[name]}
        onChangeText={formik.handleChange(name)}
        onBlur={formik.handleBlur(name)}
      />
      {formik.touched[name] && formik.errors[name]
        ? <Text style={s.errTxt}>{formik.errors[name]}</Text>
        : null}
    </View>
  );

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView contentContainerStyle={s.container} keyboardShouldPersistTaps="handled">
        <View style={s.header}>
          <View style={s.logo}><Text style={s.logoText}>SC</Text></View>
          <Text style={s.appName}>Create Account</Text>
          <Text style={s.tagline}>Join Social Connect today</Text>
        </View>
        <View style={s.card}>
          {field('name', 'Full Name', { placeholder: 'Your full name', cap: 'words' })}
          {field('email', 'Email', { placeholder: 'you@email.com', keyboard: 'email-address' })}
          {field('password', 'Password', { placeholder: 'Create a password', secure: true })}
          {field('confirmPassword', 'Confirm Password', { placeholder: 'Repeat password', secure: true })}
          <TouchableOpacity
            style={[s.btn, loading && { opacity: 0.75 }]}
            onPress={formik.handleSubmit}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading
              ? <ActivityIndicator color={Colors.white} />
              : <Text style={s.btnText}>Create Account</Text>
            }
          </TouchableOpacity>
        </View>
        <View style={s.footer}>
          <Text style={s.footerTxt}>Already have an account? </Text>
          <Link href="/(auth)/login">
            <Text style={s.footerLink}>Sign In</Text>
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: {
    flexGrow: 1, backgroundColor: Colors.background,
    paddingHorizontal: RS.padding,
    paddingTop: rh(7), paddingBottom: rh(5),
  },
  header: { alignItems: 'center', marginBottom: rh(3) },
  logo: {
    width: rw(18), height: rw(18), borderRadius: rw(9),
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: rh(2), ...SHADOWS.button,
  },
  logoText: { color: Colors.white, fontSize: RS.xl, fontWeight: '700' },
  appName: { fontSize: RS.xl, fontWeight: '700', color: Colors.text, marginBottom: rh(0.8) },
  tagline: { fontSize: RS.md, color: Colors.subText },
  card: {
    backgroundColor: Colors.cardBg, borderRadius: RS.radiusLg,
    padding: RS.cardPadding, marginBottom: rh(3), ...SHADOWS.card,
  },
  label: { fontSize: RS.sm, fontWeight: '600', color: Colors.text, marginBottom: rh(0.8) },
  input: {
    backgroundColor: Colors.inputBg, borderWidth: 1.5,
    borderColor: Colors.border, borderRadius: RS.radius,
    paddingHorizontal: rw(4), height: RS.inputHeight,
    fontSize: RS.md, color: Colors.text,
  },
  inputErr: { borderColor: Colors.error },
  errTxt: { color: Colors.error, fontSize: RS.xs, marginTop: rh(0.5) },
  btn: {
    backgroundColor: Colors.primary, borderRadius: RS.radius,
    height: RS.buttonHeight, alignItems: 'center',
    justifyContent: 'center', marginTop: rh(1), ...SHADOWS.button,
  },
  btnText: { color: Colors.white, fontSize: RS.md, fontWeight: '700' },
  footer: { flexDirection: 'row', justifyContent: 'center' },
  footerTxt: { color: Colors.subText, fontSize: RS.md },
  footerLink: { color: Colors.primary, fontSize: RS.md, fontWeight: '700' },
});