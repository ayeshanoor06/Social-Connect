import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, ActivityIndicator,
  KeyboardAvoidingView, Platform, Alert
} from 'react-native';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Link, router } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import Colors from '../../constants/colors';
import { SHADOWS } from '../../constants/theme';
import { RS, rw, rh } from '../../constants/responsive';

const schema = Yup.object({
  email: Yup.string().email('Enter a valid email').required('Email is required'),
  password: Yup.string().min(6, 'At least 6 characters').required('Password is required'),
});

function InputField({ label, placeholder, value, onChange, onBlur, error, secure, keyboard }) {
  return (
    <View style={{ marginBottom: rh(2) }}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        style={[s.input, error && s.inputErr]}
        placeholder={placeholder}
        placeholderTextColor={Colors.gray}
        keyboardType={keyboard || 'default'}
        autoCapitalize="none"
        secureTextEntry={!!secure}
        value={value}
        onChangeText={onChange}
        onBlur={onBlur}
      />
      {error ? <Text style={s.errTxt}>{error}</Text> : null}
    </View>
  );
}

export default function Login() {
  const { login, loading } = useAuth();

  const formik = useFormik({
    initialValues: { email: '', password: '' },
    validationSchema: schema,
    onSubmit: async (values) => {
  const result = await login(values.email, values.password);
  if (result.success) {
    router.replace('/(tabs)/home');
  } else {
    Alert.alert('Login Failed', result.error);
  }
},
  });

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView contentContainerStyle={s.container} keyboardShouldPersistTaps="handled">

        <View style={s.header}>
          <View style={s.logo}>
            <Text style={s.logoText}>SC</Text>
          </View>
          <Text style={s.appName}>Social Connect</Text>
          <Text style={s.tagline}>Welcome back! Sign in to continue</Text>
        </View>

        <View style={s.card}>
          <InputField
            label="Email"
            placeholder="you@email.com"
            keyboard="email-address"
            value={formik.values.email}
            onChange={formik.handleChange('email')}
            onBlur={formik.handleBlur('email')}
            error={formik.touched.email && formik.errors.email}
          />
          <InputField
            label="Password"
            placeholder="Enter your password"
            secure
            value={formik.values.password}
            onChange={formik.handleChange('password')}
            onBlur={formik.handleBlur('password')}
            error={formik.touched.password && formik.errors.password}
          />
          <TouchableOpacity style={s.forgotRow}>
            <Link href="/(auth)/forgot-password">
              <Text style={s.forgotText}>Forgot Password?</Text>
            </Link>
          </TouchableOpacity>
          <TouchableOpacity
            style={[s.btn, loading && { opacity: 0.75 }]}
            onPress={formik.handleSubmit}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading
              ? <ActivityIndicator color={Colors.white} />
              : <Text style={s.btnText}>Sign In</Text>
            }
          </TouchableOpacity>
        </View>

        <View style={s.footer}>
          <Text style={s.footerTxt}>Don't have an account? </Text>
          <Link href="/(auth)/signup">
            <Text style={s.footerLink}>Create Account</Text>
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: RS.padding,
    paddingTop: rh(8),
    paddingBottom: rh(5),
  },
  header: { alignItems: 'center', marginBottom: rh(4) },
  logo: {
    width: rw(18), height: rw(18), borderRadius: rw(9),
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: rh(2), ...SHADOWS.button,
  },
  logoText: { color: Colors.white, fontSize: RS.xl, fontWeight: '700' },
  appName: { fontSize: RS.xl, fontWeight: '700', color: Colors.text, marginBottom: rh(0.8) },
  tagline: { fontSize: RS.md, color: Colors.subText },
  card: {
    backgroundColor: Colors.cardBg,
    borderRadius: RS.radiusLg,
    padding: RS.cardPadding,
    marginBottom: rh(3),
    ...SHADOWS.card,
  },
  label: { fontSize: RS.sm, fontWeight: '600', color: Colors.text, marginBottom: rh(0.8) },
  input: {
    backgroundColor: Colors.inputBg,
    borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: RS.radius,
    paddingHorizontal: rw(4),
    height: RS.inputHeight,
    fontSize: RS.md, color: Colors.text,
  },
  inputErr: { borderColor: Colors.error },
  errTxt: { color: Colors.error, fontSize: RS.xs, marginTop: rh(0.5) },
  forgotRow: { alignSelf: 'flex-end', marginBottom: rh(2.5), marginTop: rh(0.5) },
  forgotText: { color: Colors.primary, fontSize: RS.sm, fontWeight: '600' },
  btn: {
    backgroundColor: Colors.primary,
    borderRadius: RS.radius,
    height: RS.buttonHeight,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.button,
  },
  btnText: { color: Colors.white, fontSize: RS.md, fontWeight: '700' },
  footer: { flexDirection: 'row', justifyContent: 'center' },
  footerTxt: { color: Colors.subText, fontSize: RS.md },
  footerLink: { color: Colors.primary, fontSize: RS.md, fontWeight: '700' },
});