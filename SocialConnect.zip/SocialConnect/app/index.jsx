import { Redirect } from 'expo-router';
import { useAuth } from '../context/AuthContext';

export default function Index() {
  const { user, appReady } = useAuth();

  if (!appReady) return null;

  if (user) {
    return <Redirect href="/(tabs)/home" />;
  }

  return <Redirect href="/splash" />;
}