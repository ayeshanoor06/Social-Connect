import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  Image, ActivityIndicator, Alert, ScrollView, KeyboardAvoidingView, Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { usePosts } from '../../context/PostContext';
import Colors from '../../constants/colors';
import { SIZES, SHADOWS } from '../../constants/theme';

export default function CreatePost() {
  const { user } = useAuth();
  const { addPost } = usePosts();
  const [content, setContent] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const pickImage = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed', 'Please allow access to your photos.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });
    if (!result.canceled) setImage(result.assets[0].uri);
  };

  const handlePost = async () => {
    if (!content.trim()) {
      Alert.alert('Empty post', 'Please write something before posting.');
      return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    await addPost({
  id: Date.now().toString(),
  userId: user.id,
  userName: user.name,
  userAvatar: user.avatar,
  content: content.trim(),
  image: image,
  likes: [],
  comments: [],
  createdAt: new Date().toISOString(),
}, user.id);
    setLoading(false);
    router.replace('/(tabs)/home');
  };

  return (
    <SafeAreaView style={s.container}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>

        {/* Header */}
        <View style={s.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={s.cancel}>Cancel</Text>
          </TouchableOpacity>
          <Text style={s.headerTitle}>New Post</Text>
          <TouchableOpacity
            style={[s.postBtn, (!content.trim() || loading) && s.postBtnDisabled]}
            onPress={handlePost}
            disabled={!content.trim() || loading}
          >
            {loading
              ? <ActivityIndicator color={Colors.white} size="small" />
              : <Text style={s.postBtnTxt}>Post</Text>
            }
          </TouchableOpacity>
        </View>

        <ScrollView style={{ flex: 1 }} keyboardShouldPersistTaps="handled">
          {/* User Info */}
          <View style={s.userRow}>
            <View style={s.avatar}>
              <Text style={s.avatarTxt}>{user?.name?.[0]?.toUpperCase()}</Text>
            </View>
            <Text style={s.userName}>{user?.name}</Text>
          </View>

          {/* Text Input */}
          <TextInput
            style={s.input}
            placeholder="What's on your mind?"
            placeholderTextColor={Colors.gray}
            multiline
            maxLength={500}
            value={content}
            onChangeText={setContent}
            autoFocus
          />

          <Text style={s.charCount}>{content.length}/500</Text>

          {/* Image Preview */}
          {image && (
            <View style={s.imagePreview}>
              <Image source={{ uri: image }} style={s.previewImg} resizeMode="cover" />
              <TouchableOpacity style={s.removeImg} onPress={() => setImage(null)}>
                <Text style={s.removeImgTxt}>✕</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>

        {/* Bottom Toolbar */}
        <View style={s.toolbar}>
          <TouchableOpacity style={s.toolbarBtn} onPress={pickImage}>
            <Text style={s.toolbarIcon}>🖼️</Text>
            <Text style={s.toolbarTxt}>Photo</Text>
          </TouchableOpacity>
        </View>

      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.white },
  header: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingHorizontal: 16,
    paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  cancel: { fontSize: SIZES.md, color: Colors.gray, fontWeight: '500' },
  headerTitle: { fontSize: SIZES.lg, fontWeight: '700', color: Colors.text },
  postBtn: {
    backgroundColor: Colors.primary, borderRadius: 20,
    paddingVertical: 8, paddingHorizontal: 20,
  },
  postBtnDisabled: { backgroundColor: Colors.lightGray },
  postBtnTxt: { color: Colors.white, fontWeight: '700', fontSize: SIZES.md },
  userRow: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  avatar: {
    width: 46, height: 46, borderRadius: 23,
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  avatarTxt: { color: Colors.white, fontSize: 18, fontWeight: '700' },
  userName: { fontSize: SIZES.md, fontWeight: '700', color: Colors.text },
  input: {
    fontSize: 18, color: Colors.text, paddingHorizontal: 16,
    lineHeight: 26, minHeight: 120, textAlignVertical: 'top',
  },
  charCount: { fontSize: SIZES.xs, color: Colors.gray, textAlign: 'right', marginRight: 16, marginTop: 4 },
  imagePreview: { marginHorizontal: 16, marginTop: 12, position: 'relative' },
  previewImg: { width: '100%', height: 220, borderRadius: 12 },
  removeImg: {
    position: 'absolute', top: 8, right: 8,
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center', alignItems: 'center',
  },
  removeImgTxt: { color: Colors.white, fontSize: 14, fontWeight: '700' },
  toolbar: {
    flexDirection: 'row', paddingHorizontal: 16,
    paddingVertical: 12, borderTopWidth: 1, borderTopColor: Colors.border,
  },
  toolbarBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  toolbarIcon: { fontSize: 22 },
  toolbarTxt: { fontSize: SIZES.md, color: Colors.primary, fontWeight: '600' },
});


const handlePost = async () => {
    if (!content.trim()) {
      Alert.alert('Empty post', 'Please write something before posting.');
      return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    addPost({
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,        // ← always current name
      userAvatar: user.avatar,
      content: content.trim(),
      image: image,
      likes: [],
      comments: [],
      createdAt: new Date().toISOString(),
    });
    setLoading(false);
    router.replace('/(tabs)/home');
  };