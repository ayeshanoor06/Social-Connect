import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { usePosts } from '../../context/PostContext';
import { useFollow } from '../../context/FollowContext';
import { useAuth } from '../../context/AuthContext';
import Colors from '../../constants/colors';
import { RS, rw, rh } from '../../constants/responsive';


const AVATAR_COLORS = [
  Colors.primary, Colors.secondary, Colors.teal,
  Colors.coral, Colors.accent, Colors.primaryDark,
];

function getColor(name) {
  const i = name ? name.charCodeAt(0) % AVATAR_COLORS.length : 0;
  return AVATAR_COLORS[i];
}

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function UserProfile() {
  const { userId, userName } = useLocalSearchParams();
  const { posts } = usePosts();
  const { user } = useAuth();
  const { isFollowing, followUser, unfollowUser } = useFollow();
  const [followLoading, setFollowLoading] = useState(false);
  const avatarColor = getColor(userName);

  const userPosts = posts.filter(p => p.userId === userId);
  const totalLikes = userPosts.reduce((sum, p) => sum + p.likes.length, 0);
  const totalComments = userPosts.reduce((sum, p) => sum + p.comments.length, 0);
  const alreadyFollowing = isFollowing(userId);

  const handleFollowToggle = async () => {
    setFollowLoading(true);
    if (alreadyFollowing) {
      await unfollowUser(userId);
    } else {
      await followUser(userId, userName);
    }
    setFollowLoading(false);
  };

  return (
    <SafeAreaView style={s.container}>

      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={s.backTxt}>← Back</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>Profile</Text>
        <View style={{ width: rw(15) }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Coloured Banner */}
        <View style={[s.banner, { backgroundColor: avatarColor }]}>
          <View style={s.bannerOverlay} />
        </View>

        {/* Avatar + Follow Button Row */}
        <View style={s.topSection}>
          <View style={[s.avatar, { backgroundColor: avatarColor }]}>
            <Text style={s.avatarTxt}>
              {userName ? userName[0].toUpperCase() : '?'}
            </Text>
          </View>

          {/* Follow / Unfollow Button */}
          <TouchableOpacity
            style={[
              s.followBtn,
              alreadyFollowing && s.followingBtn,
            ]}
            onPress={handleFollowToggle}
            disabled={followLoading}
            activeOpacity={0.85}
          >
            {followLoading ? (
              <ActivityIndicator
                color={alreadyFollowing ? Colors.primary : Colors.white}
                size="small"
              />
            ) : (
              <Text style={[
                s.followBtnTxt,
                alreadyFollowing && s.followingBtnTxt,
              ]}>
                {alreadyFollowing ? '✓ Following' : '+ Follow'}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Name */}
        <View style={s.infoSection}>
          <Text style={s.name}>{userName}</Text>
          <Text style={s.subTxt}>Social Connect Member</Text>



{/* Message Button */}
        <TouchableOpacity
          style={s.messageBtn}
          onPress={() => router.push({
            pathname: '/(tabs)/chat',
            params: {
              chatId: [user?.id, userId].sort().join('_'),
              otherUserId: userId,
              otherUserName: userName,
            },
          })}
          activeOpacity={0.85}
        >
          <Text style={s.messageBtnTxt}>💬 Start Chatting</Text>
        </TouchableOpacity>
          {/* Follow status badge */}
          {alreadyFollowing && (
            <View style={s.followBadge}>
              <Text style={s.followBadgeTxt}>✓ You are following {userName?.split(' ')[0]}</Text>
            </View>
          )}
        </View>

        {/* Stats */}
        <View style={s.statsRow}>
          <View style={[s.statCard, { backgroundColor: Colors.primaryLight }]}>
            <Text style={[s.statVal, { color: Colors.primary }]}>{userPosts.length}</Text>
            <Text style={[s.statLabel, { color: Colors.primaryDark }]}>Posts</Text>
          </View>
          <View style={[s.statCard, { backgroundColor: Colors.secondaryLight }]}>
            <Text style={[s.statVal, { color: Colors.secondary }]}>{totalLikes}</Text>
            <Text style={[s.statLabel, { color: Colors.secondary }]}>Likes</Text>
          </View>
          <View style={[s.statCard, { backgroundColor: Colors.tealLight }]}>
            <Text style={[s.statVal, { color: Colors.teal }]}>{totalComments}</Text>
            <Text style={[s.statLabel, { color: Colors.teal }]}>Comments</Text>
          </View>
        </View>

        {/* Posts */}
        <View style={s.postsSection}>
          <Text style={s.postsTitle}>
            {userName ? userName.split(' ')[0] : 'User'}'s Posts ({userPosts.length})
          </Text>

          {userPosts.length === 0 ? (
            <View style={s.emptyWrap}>
              <Text style={{ fontSize: 40, marginBottom: 8 }}>📭</Text>
              <Text style={s.emptyTxt}>No posts yet</Text>
            </View>
          ) : (
            userPosts.map(post => (
              <View key={post.id} style={s.postCard}>
                <Text style={s.postContent}>{post.content}</Text>
                <View style={s.postMeta}>
                  <Text style={s.postTime}>{timeAgo(post.createdAt)}</Text>
                  <View style={s.postStats}>
                    <Text style={s.postStat}>❤️ {post.likes.length}</Text>
                    <Text style={s.postStat}>💬 {post.comments.length}</Text>
                  </View>
                </View>
              </View>
            ))
          )}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: rw(5), paddingVertical: rh(1.5),
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backTxt: { color: Colors.primary, fontSize: RS.md, fontWeight: '600' },
  headerTitle: { fontSize: RS.lg, fontWeight: '700', color: Colors.text },
  banner: { height: rh(18), overflow: 'hidden' },
  bannerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.1)',
  },
  topSection: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: rw(5),
    marginTop: -rw(12),
    marginBottom: rh(1),
  },
  avatar: {
    width: rw(24), height: rw(24), borderRadius: rw(12),
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 4, borderColor: Colors.white,
    elevation: 8, shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2, shadowRadius: 8,
  },
  avatarTxt: { fontSize: RS.xxl, fontWeight: '800', color: Colors.white },
  followBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 25, paddingVertical: rh(1.2),
    paddingHorizontal: rw(7),
    elevation: 4, shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3, shadowRadius: 6,
    minWidth: rw(30), alignItems: 'center',
  },
  followingBtn: {
    backgroundColor: Colors.white,
    borderWidth: 2, borderColor: Colors.primary,
    elevation: 0,
  },
  followBtnTxt: {
    color: Colors.white,
    fontWeight: '700', fontSize: RS.md,
  },
  followingBtnTxt: { color: Colors.primary },
  infoSection: {
    alignItems: 'center', marginBottom: rh(2),
    paddingHorizontal: rw(5),
  },
  name: { fontSize: RS.xl, fontWeight: '800', color: Colors.text, marginBottom: 4 },
  subTxt: { fontSize: RS.sm, color: Colors.subText, marginBottom: rh(1) },
  followBadge: {
    backgroundColor: Colors.tealLight,
    paddingHorizontal: rw(4), paddingVertical: rh(0.6),
    borderRadius: 20, marginTop: rh(0.5),
  },
  followBadgeTxt: {
    color: Colors.teal, fontSize: RS.xs, fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row', marginHorizontal: rw(4),
    gap: rw(3), marginBottom: rh(2),
  },
  statCard: {
    flex: 1, borderRadius: 16,
    padding: rw(4), alignItems: 'center',
  },
  statVal: { fontSize: RS.xl, fontWeight: '800', marginBottom: 2 },
  statLabel: { fontSize: RS.xs, fontWeight: '600' },
  postsSection: { marginHorizontal: rw(4), marginBottom: rh(4) },
  postsTitle: {
    fontSize: RS.md, fontWeight: '700',
    color: Colors.text, marginBottom: rh(1.5),
  },
  postCard: {
    backgroundColor: Colors.white, borderRadius: 14,
    padding: rw(4), marginBottom: rh(1.2),
    borderWidth: 1, borderColor: Colors.border,
    elevation: 1,
  },
  postContent: {
    fontSize: RS.md, color: Colors.text,
    lineHeight: 22, marginBottom: rh(1),
  },
  postMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between', alignItems: 'center',
  },
  postTime: { fontSize: RS.xs, color: Colors.subText },
  postStats: { flexDirection: 'row', gap: rw(3) },
  postStat: { fontSize: RS.sm, color: Colors.subText },
  emptyWrap: { alignItems: 'center', paddingVertical: rh(4) },
  emptyTxt: { fontSize: RS.md, color: Colors.subText },


  messageBtn: {
    backgroundColor: Colors.primaryDark,
    borderRadius: 25, paddingVertical: rh(1.2),
    paddingHorizontal: rw(5), marginTop: rh(1),
    alignItems: 'center',
  },
  messageBtnTxt: {
    color: Colors.white, fontWeight: '700', fontSize: RS.md,
  },
});