import {
  View, Text, StyleSheet, TouchableOpacity,
  Switch, ScrollView, Alert, Linking
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { registerForNotifications } from '../../utils/notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Colors from '../../constants/colors';

export default function Settings() {
  const { user, logout } = useAuth();
  const [notifEnabled, setNotifEnabled] = useState(false);
  const [likeNotif, setLikeNotif] = useState(true);
  const [commentNotif, setCommentNotif] = useState(true);

  // Load saved notification preferences
  useEffect(() => {
    const loadPrefs = async () => {
      try {
        const prefs = await AsyncStorage.getItem('notifPrefs');
        if (prefs) {
          const parsed = JSON.parse(prefs);
          setNotifEnabled(parsed.notifEnabled ?? false);
          setLikeNotif(parsed.likeNotif ?? true);
          setCommentNotif(parsed.commentNotif ?? true);
        }
        const granted = await registerForNotifications();
        setNotifEnabled(granted);
      } catch {}
    };
    loadPrefs();
  }, []);

  const savePrefs = async (prefs) => {
    try {
      await AsyncStorage.setItem('notifPrefs', JSON.stringify(prefs));
    } catch {}
  };

  const handleMainToggle = async (val) => {
    if (val) {
      const granted = await registerForNotifications();
      if (!granted) {
        Alert.alert(
          'Permission Denied',
          'Please enable notifications in your device Settings app to receive alerts.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Open Settings', onPress: () => Linking.openSettings() },
          ]
        );
        return;
      }
      setNotifEnabled(true);
      await savePrefs({ notifEnabled: true, likeNotif, commentNotif });
    } else {
      setNotifEnabled(false);
      await savePrefs({ notifEnabled: false, likeNotif, commentNotif });
    }
  };

  const handleLikeToggle = async (val) => {
    setLikeNotif(val);
    await savePrefs({ notifEnabled, likeNotif: val, commentNotif });
  };

  const handleCommentToggle = async (val) => {
    setCommentNotif(val);
    await savePrefs({ notifEnabled, likeNotif, commentNotif: val });
  };

  const handleLogout = () => {
    Alert.alert('Log Out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log Out', style: 'destructive', onPress: logout },
    ]);
  };

  const openPrivacyPolicy = () => {
    Alert.alert(
      '🔒 Privacy Policy',
      `Last updated: April 2026\n\n` +
      `1. DATA WE COLLECT\nWe collect your name, email address, profile picture, and content you post on Social Connect.\n\n` +
      `2. HOW WE USE YOUR DATA\nYour data is used to provide and improve our services, personalize your experience, and send you notifications about activity on your posts.\n\n` +
      `3. DATA SHARING\nWe do not sell your personal data to third parties. Your posts and profile are visible to other users of Social Connect.\n\n` +
      `4. DATA SECURITY\nWe take reasonable measures to protect your information from unauthorized access or disclosure.\n\n` +
      `6. CONTACT US\nFor privacy concerns, contact us at privacy@socialconnect.app`,
      [{ text: 'Close', style: 'cancel' }]
    );
  };

  const openTerms = () => {
    Alert.alert(
      '📋 Terms of Service',
      `Last updated: April 2026\n\n` +
      `1. ACCEPTANCE\nBy using Social Connect, you agree to these Terms of Service. If you disagree, please do not use the app.\n\n` +
      `2. YOUR ACCOUNT\nYou are responsible for maintaining the confidentiality of your account. You must be at least 13 years old to use this service.\n\n` +
      `3. CONTENT RULES\nYou may not post content that is illegal, harmful, threatening, abusive, or violates others' rights. We reserve the right to remove any content.\n\n` +
      `4. INTELLECTUAL PROPERTY\nYou retain ownership of content you post. By posting, you grant Social Connect a license to display your content.\n\n` +
      `5. TERMINATION\nWe may terminate your account if you violate these terms.\n\n` +
      `6. DISCLAIMER\nSocial Connect is provided "as is" without warranties of any kind.\n\n` +
      `7. CONTACT\nFor questions about these terms: terms@socialconnect.app`,
      [{ text: 'Close', style: 'cancel' }]
    );
  };

  const openAbout = () => {
    Alert.alert(
      'ℹ️ About Social Connect',
      `Social Connect v1.0.0\n\n` +
      `A minimal social media platform where you can:\n` +
      `• Share posts and photos\n` +
      `• Like and comment on posts\n` +
      `• View other users' profiles\n` +
      `• Get notified about activity\n\n` +
      `Built with React Native & Expo\n\n` +
      `© 2026 Social Connect. All rights reserved.`,
      [{ text: 'Close', style: 'cancel' }]
    );
  };

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <Text style={s.headerTitle}>Settings</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>

        {/* Profile Card */}
        <View style={s.profileCard}>
          <View style={s.avatar}>
            <Text style={s.avatarTxt}>{user?.name?.[0]?.toUpperCase()}</Text>
          </View>
          <View>
            <Text style={s.profileName}>{user?.name}</Text>
            <Text style={s.profileEmail}>{user?.email}</Text>
          </View>
        </View>

        {/* Notifications Section */}
        <Text style={s.sectionTitle}>NOTIFICATIONS</Text>
        <View style={s.card}>

          <View style={s.row}>
            <Text style={s.rowIcon}>🔔</Text>
            <View style={s.rowInfo}>
              <Text style={s.rowLabel}>Push Notifications</Text>
              <Text style={s.rowSub}>Receive alerts on your device</Text>
            </View>
            <Switch
              value={notifEnabled}
              onValueChange={handleMainToggle}
              trackColor={{ false: Colors.lightGray, true: Colors.primaryLight }}
              thumbColor={notifEnabled ? Colors.primary : Colors.gray}
            />
          </View>

          <View style={s.divider} />

          <View style={[s.row, !notifEnabled && s.rowDisabled]}>
            <Text style={s.rowIcon}>❤️</Text>
            <View style={s.rowInfo}>
              <Text style={s.rowLabel}>Like Notifications</Text>
              <Text style={s.rowSub}>
                {notifEnabled && likeNotif
                  ? '✅ Active — you will be notified'
                  : '❌ Off — you will not be notified'}
              </Text>
            </View>
            <Switch
              value={likeNotif && notifEnabled}
              onValueChange={handleLikeToggle}
              disabled={!notifEnabled}
              trackColor={{ false: Colors.lightGray, true: Colors.secondaryLight }}
              thumbColor={likeNotif && notifEnabled ? Colors.secondary : Colors.gray}
            />
          </View>

          <View style={s.divider} />

          <View style={[s.row, !notifEnabled && s.rowDisabled]}>
            <Text style={s.rowIcon}>💬</Text>
            <View style={s.rowInfo}>
              <Text style={s.rowLabel}>Comment Notifications</Text>
              <Text style={s.rowSub}>
                {notifEnabled && commentNotif
                  ? '✅ Active — you will be notified'
                  : '❌ Off — you will not be notified'}
              </Text>
            </View>
            <Switch
              value={commentNotif && notifEnabled}
              onValueChange={handleCommentToggle}
              disabled={!notifEnabled}
              trackColor={{ false: Colors.lightGray, true: Colors.primaryLight }}
              thumbColor={commentNotif && notifEnabled ? Colors.primary : Colors.gray}
            />
          </View>

        </View>

        {/* Notification Status Banner */}
        <View style={[s.statusBanner, {
          backgroundColor: notifEnabled ? Colors.tealLight : '#FFF0F0'
        }]}>
          <Text style={{ fontSize: 16 }}>{notifEnabled ? '🔔' : '🔕'}</Text>
          <Text style={[s.statusTxt, { color: notifEnabled ? Colors.teal : Colors.error }]}>
            {notifEnabled
              ? 'Notifications are ON — you will receive alerts'
              : 'Notifications are OFF — turn on to receive alerts'}
          </Text>
        </View>

        {/* Account Section */}
        <Text style={s.sectionTitle}>ACCOUNT</Text>
        <View style={s.card}>
          <TouchableOpacity style={s.row} onPress={openPrivacyPolicy} activeOpacity={0.7}>
            <Text style={s.rowIcon}>🔒</Text>
            <Text style={[s.rowLabel, { flex: 1 }]}>Privacy Policy</Text>
            <Text style={s.chevron}>›</Text>
          </TouchableOpacity>

          <View style={s.divider} />

          <TouchableOpacity style={s.row} onPress={openTerms} activeOpacity={0.7}>
            <Text style={s.rowIcon}>📋</Text>
            <Text style={[s.rowLabel, { flex: 1 }]}>Terms of Service</Text>
            <Text style={s.chevron}>›</Text>
          </TouchableOpacity>

          <View style={s.divider} />

          <TouchableOpacity style={s.row} onPress={openAbout} activeOpacity={0.7}>
            <Text style={s.rowIcon}>ℹ️</Text>
            <Text style={[s.rowLabel, { flex: 1 }]}>About Social Connect</Text>
            <Text style={s.chevron}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Logout */}
        <TouchableOpacity style={s.logoutBtn} onPress={handleLogout} activeOpacity={0.85}>
          <Text style={s.logoutTxt}>🚪  Log Out</Text>
        </TouchableOpacity>

        <Text style={s.version}>Social Connect v1.0.0</Text>

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20, paddingVertical: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { fontSize: 22, fontWeight: '700', color: Colors.primary },
  profileCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.white, margin: 16,
    borderRadius: 16, padding: 16, gap: 14,
    borderWidth: 1, borderColor: Colors.border,
    elevation: 2, shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 4,
  },
  avatar: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  avatarTxt: { color: Colors.white, fontSize: 20, fontWeight: '700' },
  profileName: { fontSize: 15, fontWeight: '700', color: Colors.text },
  profileEmail: { fontSize: 12, color: Colors.subText, marginTop: 2 },
  sectionTitle: {
    fontSize: 11, fontWeight: '700', color: Colors.subText,
    marginHorizontal: 20, marginTop: 8, marginBottom: 8,
    letterSpacing: 1,
  },
  card: {
    backgroundColor: Colors.white, borderRadius: 16,
    marginHorizontal: 16, marginBottom: 12,
    borderWidth: 1, borderColor: Colors.border,
    overflow: 'hidden',
    elevation: 2, shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 4,
  },
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14, gap: 12,
  },
  rowDisabled: { opacity: 0.4 },
  rowIcon: { fontSize: 20, width: 28, textAlign: 'center' },
  rowInfo: { flex: 1 },
  rowLabel: { fontSize: 14, fontWeight: '600', color: Colors.text },
  rowSub: { fontSize: 11, color: Colors.subText, marginTop: 2 },
  divider: { height: 1, backgroundColor: Colors.border, marginLeft: 56 },
  chevron: { color: Colors.gray, fontSize: 20, fontWeight: '300' },
  statusBanner: {
    flexDirection: 'row', alignItems: 'center',
    marginHorizontal: 16, marginBottom: 16,
    padding: 12, borderRadius: 12, gap: 8,
  },
  statusTxt: { fontSize: 12, fontWeight: '600', flex: 1 },
  logoutBtn: {
    marginHorizontal: 16, marginTop: 8,
    backgroundColor: '#FFF0F0', borderRadius: 16,
    paddingVertical: 16, alignItems: 'center',
    borderWidth: 1.5, borderColor: '#FFD0D0',
  },
  logoutTxt: { color: Colors.error, fontWeight: '700', fontSize: 15 },
  version: { textAlign: 'center', color: Colors.subText, fontSize: 11, marginTop: 16 },
});