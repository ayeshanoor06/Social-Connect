import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, RefreshControl
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import { router } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useMessages } from '../../context/MessageContext';
import Colors from '../../constants/colors';
import { RS, rw, rh } from '../../constants/responsive';

const AVATAR_COLORS = [
  Colors.primary, Colors.secondary, Colors.teal,
  Colors.coral, Colors.accent, Colors.primaryDark,
];

function getColor(name) {
  const i = name ? name.charCodeAt(0) % AVATAR_COLORS.length : 0;
  return AVATAR_COLORS[i];
}

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function Messages() {
  const { user } = useAuth();
  const { conversations, loadConversations, getTotalUnread } = useMessages();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (user?.id) loadConversations(user.id);
  }, [user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    if (user?.id) await loadConversations(user.id);
    setRefreshing(false);
  };

  const openChat = (convo) => {
    router.push({
      pathname: '/(tabs)/chat',
      params: {
        chatId: convo.chatId,
        otherUserId: convo.otherUserId,
        otherUserName: convo.otherUserName,
      },
    });
  };

  return (
    <SafeAreaView style={s.container}>

      {/* Header */}
      <View style={s.header}>
        <Text style={s.headerTitle}>Messages</Text>
        {getTotalUnread() > 0 && (
          <View style={s.unreadBadge}>
            <Text style={s.unreadBadgeTxt}>{getTotalUnread()}</Text>
          </View>
        )}
      </View>

      <FlatList
        data={conversations}
        keyExtractor={item => item.chatId}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100, flexGrow: 1 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.primary]}
          />
        }
        ListEmptyComponent={
          <View style={s.emptyWrap}>
            <Text style={s.emptyIcon}>💬</Text>
            <Text style={s.emptyTitle}>No Messages Yet</Text>
            <Text style={s.emptyTxt}>
              Visit someone's profile and tap{'\n'}"Send Message" to start chatting!
            </Text>
          </View>
        }
        renderItem={({ item }) => {
          const color = getColor(item.otherUserName);
          return (
            <TouchableOpacity
              style={s.convoItem}
              onPress={() => openChat(item)}
              activeOpacity={0.7}
            >
              {/* Avatar */}
              <View style={[s.avatar, { backgroundColor: color }]}>
                <Text style={s.avatarTxt}>
                  {item.otherUserName?.[0]?.toUpperCase()}
                </Text>
              </View>

              {/* Info */}
              <View style={s.convoInfo}>
                <View style={s.convoTop}>
                  <Text style={s.convoName}>{item.otherUserName}</Text>
                  <Text style={s.convoTime}>{timeAgo(item.lastMessageTime)}</Text>
                </View>
                <View style={s.convoBottom}>
                  <Text
                    style={[s.convoLastMsg, item.unread > 0 && s.convoLastMsgUnread]}
                    numberOfLines={1}
                  >
                    {item.lastMessage}
                  </Text>
                  {item.unread > 0 && (
                    <View style={s.unreadDot}>
                      <Text style={s.unreadDotTxt}>{item.unread}</Text>
                    </View>
                  )}
                </View>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: rw(5), paddingVertical: rh(2),
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    gap: rw(3),
  },
  headerTitle: { fontSize: RS.xl, fontWeight: '800', color: Colors.primary, flex: 1 },
  unreadBadge: {
    backgroundColor: Colors.secondary, borderRadius: 12,
    paddingHorizontal: rw(2.5), paddingVertical: 2,
    minWidth: rw(6), alignItems: 'center',
  },
  unreadBadgeTxt: { color: Colors.white, fontSize: RS.xs, fontWeight: '700' },
  emptyWrap: {
    flex: 1, alignItems: 'center',
    justifyContent: 'center', paddingTop: rh(15),
  },
  emptyIcon: { fontSize: 64, marginBottom: rh(2) },
  emptyTitle: { fontSize: RS.xl, fontWeight: '700', color: Colors.text, marginBottom: rh(1) },
  emptyTxt: {
    fontSize: RS.md, color: Colors.subText,
    textAlign: 'center', lineHeight: 22,
  },
  convoItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.white, paddingHorizontal: rw(5),
    paddingVertical: rh(1.8), borderBottomWidth: 1,
    borderBottomColor: Colors.border, gap: rw(3),
  },
  avatar: {
    width: rw(13), height: rw(13), borderRadius: rw(7),
    justifyContent: 'center', alignItems: 'center',
  },
  avatarTxt: { color: Colors.white, fontSize: RS.lg, fontWeight: '700' },
  convoInfo: { flex: 1 },
  convoTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  convoName: { fontSize: RS.md, fontWeight: '700', color: Colors.text },
  convoTime: { fontSize: RS.xs, color: Colors.subText },
  convoBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  convoLastMsg: { fontSize: RS.sm, color: Colors.subText, flex: 1 },
  convoLastMsgUnread: { color: Colors.text, fontWeight: '600' },
  unreadDot: {
    backgroundColor: Colors.primary, borderRadius: 10,
    minWidth: rw(5), height: rw(5),
    justifyContent: 'center', alignItems: 'center',
    paddingHorizontal: 4,
  },
  unreadDotTxt: { color: Colors.white, fontSize: RS.xs, fontWeight: '700' },
});