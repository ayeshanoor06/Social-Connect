import {
  View, Text, StyleSheet, TouchableOpacity,
  Image, ScrollView
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useFollow } from '../../context/FollowContext';
import { usePosts } from '../../context/PostContext';
import Colors from '../../constants/colors';
import { RS, rw, rh } from '../../constants/responsive';

export default function Profile() {
  const { user, logout } = useAuth();
  const { getFollowingCount, getFollowersCount } = useFollow();
  const { posts } = usePosts();

  const myPosts = posts.filter(p => p.userId === user?.id);

  return (
    <SafeAreaView style={s.container}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Banner */}
        <View style={s.banner}>
          <View style={s.bannerPattern}>
            {[...Array(6)].map((_, i) => (
              <View key={i} style={[s.bannerCircle, {
                width: rw(20 + i * 5),
                height: rw(20 + i * 5),
                borderRadius: rw(12 + i * 3),
                opacity: 0.08 + i * 0.02,
                top: -rw(5 + i * 3),
                right: -rw(5 + i * 2),
              }]} />
            ))}
          </View>
          <Text style={s.bannerTitle}>My Profile</Text>
        </View>

        {/* Avatar */}
        <View style={s.avatarSection}>
          {user?.avatar ? (
            <Image source={{ uri: user.avatar }} style={s.avatarImg} />
          ) : (
            <View style={s.avatar}>
              <Text style={s.avatarTxt}>{user?.name?.[0]?.toUpperCase() || 'U'}</Text>
            </View>
          )}
          <View style={s.onlineDot} />
        </View>

        {/* Info */}
        <View style={s.infoSection}>
          <Text style={s.name}>{user?.name}</Text>
          <Text style={s.email}>{user?.email}</Text>
          {user?.bio ? <Text style={s.bio}>{user.bio}</Text> : null}
        </View>

        {/* Stats */}
        <View style={s.statsRow}>
          <View style={[s.statCard, { backgroundColor: Colors.primaryLight }]}>
            <Text style={[s.statVal, { color: Colors.primary }]}>{myPosts.length}</Text>
            <Text style={[s.statLabel, { color: Colors.primaryDark }]}>Posts</Text>
          </View>
          <View style={[s.statCard, { backgroundColor: Colors.secondaryLight }]}>
            <Text style={[s.statVal, { color: Colors.secondary }]}>{getFollowersCount()}</Text>
            <Text style={[s.statLabel, { color: Colors.secondary }]}>Followers</Text>
          </View>
          <View style={[s.statCard, { backgroundColor: Colors.tealLight }]}>
            <Text style={[s.statVal, { color: Colors.teal }]}>{getFollowingCount()}</Text>
            <Text style={[s.statLabel, { color: Colors.teal }]}>Following</Text>
          </View>
        </View>

        {/* Buttons */}
        <View style={s.btnSection}>
          <TouchableOpacity
            style={s.editBtn}
            onPress={() => router.push('/(tabs)/edit-profile')}
            activeOpacity={0.85}
          >
            <Text style={s.editBtnTxt}>Edit Profile </Text>
          </TouchableOpacity>

          
        </View>

        {/* My Posts */}
        <View style={s.myPostsSection}>
          <Text style={s.myPostsTitle}>My Posts ({myPosts.length})</Text>
          {myPosts.length === 0 ? (
            <View style={s.emptyWrap}>
              <Text style={{ fontSize: 40, marginBottom: 8 }}>📝</Text>
              <Text style={s.emptyTxt}>No posts yet. Create your first post!</Text>
              <TouchableOpacity
                style={s.createPostBtn}
                onPress={() => router.push('/(tabs)/create-post')}
              >
                <Text style={s.createPostBtnTxt}>+ Create Post</Text>
              </TouchableOpacity>
            </View>
          ) : (
            myPosts.map(post => (
  <View key={post.id} style={s.postCard}>
    {/* Post Image */}
    {post.image && (
      <Image
        source={{ uri: post.image }}
        style={s.postImage}
        resizeMode="cover"
      />
    )}
    <View style={s.postCardBody}>
      <Text style={s.postContent} numberOfLines={3}>{post.content}</Text>
      <View style={s.postMeta}>
        <Text style={s.postTime}>
          {post.edited ? '· edited' : ''}
        </Text>
        <View style={s.postStats}>
          <Text style={s.postStat}>❤️ {post.likes.length}</Text>
          <Text style={s.postStat}>💬 {post.comments.length}</Text>
        </View>
      </View>
    </View>
  </View>
))
          )}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  banner: {
    backgroundColor: Colors.primary, height: rh(18),
    justifyContent: 'flex-end', paddingBottom: rh(5),
    paddingHorizontal: rw(5), overflow: 'hidden',
  },
  bannerPattern: { position: 'absolute', top: 0, right: 0, bottom: 0 },
  bannerCircle: { position: 'absolute', backgroundColor: Colors.white },
  bannerTitle: { fontSize: RS.xxl, fontWeight: '800', color: Colors.white },
  avatarSection: {
    alignItems: 'center', marginTop: -rw(12),
    marginBottom: rh(1), position: 'relative',
  },
  avatarImg: {
    width: rw(24), height: rw(24), borderRadius: rw(12),
    borderWidth: 4, borderColor: Colors.white,
  },
  avatar: {
    width: rw(24), height: rw(24), borderRadius: rw(12),
    backgroundColor: Colors.primary, justifyContent: 'center',
    alignItems: 'center', borderWidth: 4, borderColor: Colors.white,
    elevation: 8, shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 8,
  },
  avatarTxt: { fontSize: RS.xxl, fontWeight: '800', color: Colors.white },
  onlineDot: {
    position: 'absolute', bottom: rh(0.5), right: rw(40),
    width: rw(4), height: rw(4), borderRadius: rw(2),
    backgroundColor: Colors.teal, borderWidth: 2, borderColor: Colors.white,
  },
  infoSection: { alignItems: 'center', paddingHorizontal: rw(5), marginBottom: rh(2) },
  name: { fontSize: RS.xl, fontWeight: '800', color: Colors.text, marginBottom: rh(0.3) },
  email: { fontSize: RS.sm, color: Colors.subText, marginBottom: rh(0.5) },
  bio: { fontSize: RS.md, color: Colors.text, textAlign: 'center', lineHeight: 22 },
  statsRow: {
    flexDirection: 'row', marginHorizontal: rw(4),
    gap: rw(3), marginBottom: rh(2),
  },
  statCard: {
    flex: 1, borderRadius: 16,
    padding: rw(4), alignItems: 'center',
  },
  statVal: { fontSize: RS.xl, fontWeight: '800', marginBottom: 2 },
  statLabel: { fontSize: RS.xs, fontWeight: '600' },
  btnSection: { marginHorizontal: rw(4), gap: rh(1.2), marginBottom: rh(2) },
  editBtn: {
    backgroundColor: Colors.primary, borderRadius: 14,
    paddingVertical: rh(1.8), alignItems: 'center',
    elevation: 4, shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3, shadowRadius: 6,
  },
  editBtnTxt: { color: Colors.white, fontWeight: '700', fontSize: RS.md },
 
  myPostsSection: { marginHorizontal: rw(4), marginBottom: rh(4) },
  myPostsTitle: { fontSize: RS.md, fontWeight: '700', color: Colors.text, marginBottom: rh(1.5) },
  postCard: {
    backgroundColor: Colors.white,
    borderRadius: 14,
    marginBottom: rh(1.2),
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
  },
  postContent: { fontSize: RS.md, color: Colors.text, lineHeight: 22, marginBottom: rh(1) },
  postMeta: { flexDirection: 'row', justifyContent: 'flex-end' },
  postStats: { flexDirection: 'row', gap: rw(3) },
  postStat: { fontSize: RS.sm, color: Colors.subText },
  emptyWrap: { alignItems: 'center', paddingVertical: rh(3) },
  emptyTxt: { fontSize: RS.sm, color: Colors.subText, marginBottom: rh(1.5), textAlign: 'center' },
  createPostBtn: {
    backgroundColor: Colors.primary, borderRadius: 12,
    paddingVertical: rh(1.2), paddingHorizontal: rw(8),
  },
  createPostBtnTxt: { color: Colors.white, fontWeight: '700', fontSize: RS.md },

  postImage: {
    width: '100%',
    height: rh(22),
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    marginBottom: 0,
  },
  postCardBody: {
    padding: rw(4),
  },
  postTime: {
    fontSize: RS.xs,
    color: Colors.gray,
    fontStyle: 'italic',
  },
});