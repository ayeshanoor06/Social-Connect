import { Tabs } from 'expo-router';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '../../constants/colors';
import { rh, rw } from '../../constants/responsive';
import { useMessages } from '../../context/MessageContext';

function TabIcon({ focused, icon, label, activeColor, badge }) {
  return (
    <View style={s.iconWrap}>
      <View>
        <Text style={[s.icon, focused && { opacity: 1 }, !focused && { opacity: 0.5 }]}>
          {icon}
        </Text>
        {badge > 0 && (
          <View style={s.badge}>
            <Text style={s.badgeTxt}>{badge > 9 ? '9+' : badge}</Text>
          </View>
        )}
      </View>
      <Text style={[s.label, focused && { color: activeColor, fontWeight: '700' }]}>
        {label}
      </Text>
    </View>
  );
}

export default function TabsLayout() {
  const { getTotalUnread } = useMessages();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: s.tabBar,
        tabBarShowLabel: false,
        tabBarActiveTintColor: Colors.primary,
      }}
    >
      <Tabs.Screen
        name="home"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused} icon="🏠" label="Home"
              activeColor={Colors.primary} />
          ),
        }}
      />
      <Tabs.Screen
        name="search"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused} icon="🔍" label="Search"
              activeColor={Colors.primary} />
          ),
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused} icon="💬" label="Chats"
              activeColor={Colors.primary}
              badge={getTotalUnread()} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused} icon="👤" label="Profile"
              activeColor={Colors.primary} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused} icon="⚙️" label="Settings"
              activeColor={Colors.primary} />
          ),
        }}
      />
      <Tabs.Screen name="create-post" options={{ href: null }} />
      <Tabs.Screen name="edit-profile" options={{ href: null }} />
      <Tabs.Screen name="user-profile" options={{ href: null }} />
      <Tabs.Screen name="chat" options={{ href: null }} />
    </Tabs>
  );
}

const s = StyleSheet.create({
  tabBar: {
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    height: rh(9),
    paddingBottom: rh(1),
    paddingTop: rh(0.8),
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
  },
  iconWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: rw(2),
    paddingVertical: rh(0.3),
    minWidth: rw(16),
  },
  icon: {
    fontSize: 22,
    marginBottom: 3,
    textAlign: 'center',
  },
  label: {
    fontSize: 10,
    color: Colors.gray,
    fontWeight: '500',
    textAlign: 'center',
  },
  badge: {
    position: 'absolute',
    top: -4, right: -8,
    backgroundColor: Colors.secondary,
    borderRadius: 8,
    minWidth: 16, height: 16,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 3,
  },
  badgeTxt: {
    color: Colors.white,
    fontSize: 9,
    fontWeight: '700',
  },
});