import {
  View, Text, StyleSheet, FlatList,
  TextInput, TouchableOpacity, KeyboardAvoidingView,
  Platform, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState, useRef } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useMessages } from '../../context/MessageContext';
import Colors from '../../constants/colors';
import { RS, rw, rh } from '../../constants/responsive';

const AVATAR_COLORS = [
  Colors.primary, Colors.secondary, Colors.teal,
  Colors.coral, Colors.accent, Colors.primaryDark,
];

function getColor(name) {
  const i = name ? name.charCodeAt(0) % AVATAR_COLORS.length : 0;
  return AVATAR_COLORS[i];
}

function timeStr(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export default function Chat() {
  const { chatId, otherUserId, otherUserName } = useLocalSearchParams();
  const { user } = useAuth();
  const { messages, loadMessages, sendMessage, markAsRead } = useMessages();
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const flatListRef = useRef(null);
  const avatarColor = getColor(otherUserName);

  const chatMessages = messages[chatId] || [];

  useEffect(() => {
    if (chatId) {
      loadMessages(chatId);
      markAsRead(chatId);
    }
  }, [chatId]);

  useEffect(() => {
    if (chatMessages.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [chatMessages.length]);

  const handleSend = async () => {
    if (!text.trim() || sending) return;
    const msgText = text.trim();
    setText('');
    setSending(true);
    await sendMessage(otherUserId, otherUserName, user, msgText);
    setSending(false);
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const renderMessage = ({ item, index }) => {
    const isMe = item.senderId === user?.id;
    const prevMsg = chatMessages[index - 1];
    const showTime = !prevMsg ||
      new Date(item.createdAt) - new Date(prevMsg.createdAt) > 300000;

    return (
      <View>
        {showTime && (
          <Text style={s.timeLabel}>{timeStr(item.createdAt)}</Text>
        )}
        <View style={[s.msgRow, isMe && s.msgRowMe]}>
          {!isMe && (
            <View style={[s.msgAvatar, { backgroundColor: avatarColor }]}>
              <Text style={s.msgAvatarTxt}>
                {otherUserName?.[0]?.toUpperCase()}
              </Text>
            </View>
          )}
          <View style={[s.bubble, isMe ? s.bubbleMe : s.bubbleThem]}>
            <Text style={[s.bubbleTxt, isMe && s.bubbleTxtMe]}>
              {item.text}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={s.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >

        {/* Header */}
        <View style={s.header}>
          <TouchableOpacity onPress={() => router.back()} style={s.backBtn}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <View style={[s.headerAvatar, { backgroundColor: avatarColor }]}>
            <Text style={s.headerAvatarTxt}>
              {otherUserName?.[0]?.toUpperCase()}
            </Text>
          </View>
          <View style={s.headerInfo}>
            <Text style={s.headerName}>{otherUserName}</Text>
            <Text style={s.headerStatus}>● Online</Text>
          </View>
        </View>

        {/* Messages */}
        {chatMessages.length === 0 ? (
          <View style={s.emptyWrap}>
            <Text style={s.emptyIcon}>👋</Text>
            <Text style={s.emptyTxt}>
              Say hello to {otherUserName?.split(' ')[0]}!
            </Text>
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={chatMessages}
            keyExtractor={item => item.id}
            contentContainerStyle={s.msgList}
            showsVerticalScrollIndicator={false}
            renderItem={renderMessage}
            onContentSizeChange={() =>
              flatListRef.current?.scrollToEnd({ animated: false })
            }
          />
        )}

        {/* Input Bar */}
        <View style={s.inputBar}>
          <TextInput
            style={s.input}
            value={text}
            onChangeText={setText}
            placeholder={`Message ${otherUserName?.split(' ')[0]}...`}
            placeholderTextColor={Colors.gray}
            multiline
            maxLength={500}
            onSubmitEditing={handleSend}
          />
          <TouchableOpacity
            style={[s.sendBtn, (!text.trim() || sending) && s.sendBtnDisabled]}
            onPress={handleSend}
            disabled={!text.trim() || sending}
            activeOpacity={0.85}
          >
            {sending
              ? <ActivityIndicator color={Colors.white} size="small" />
              : <Text style={s.sendIcon}>➤</Text>
            }
          </TouchableOpacity>
        </View>

      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.white, paddingHorizontal: rw(4),
    paddingVertical: rh(1.5), borderBottomWidth: 1,
    borderBottomColor: Colors.border, gap: rw(3),
  },
  backBtn: { padding: rw(1) },
  backTxt: { fontSize: RS.xl, color: Colors.primary, fontWeight: '700' },
  headerAvatar: {
    width: rw(10), height: rw(10), borderRadius: rw(5),
    justifyContent: 'center', alignItems: 'center',
  },
  headerAvatarTxt: { color: Colors.white, fontSize: RS.md, fontWeight: '700' },
  headerInfo: { flex: 1 },
  headerName: { fontSize: RS.md, fontWeight: '700', color: Colors.text },
  headerStatus: { fontSize: RS.xs, color: Colors.teal, fontWeight: '600' },
  emptyWrap: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
  },
  emptyIcon: { fontSize: 56, marginBottom: rh(1.5) },
  emptyTxt: { fontSize: RS.md, color: Colors.subText },
  msgList: {
    paddingHorizontal: rw(4), paddingVertical: rh(2),
    paddingBottom: rh(3),
  },
  timeLabel: {
    textAlign: 'center', fontSize: RS.xs,
    color: Colors.subText, marginVertical: rh(1),
  },
  msgRow: {
    flexDirection: 'row', alignItems: 'flex-end',
    marginBottom: rh(0.8), gap: rw(2),
  },
  msgRowMe: { justifyContent: 'flex-end' },
  msgAvatar: {
    width: rw(8), height: rw(8), borderRadius: rw(4),
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 2,
  },
  msgAvatarTxt: { color: Colors.white, fontSize: RS.xs, fontWeight: '700' },
  bubble: {
    maxWidth: '75%', paddingHorizontal: rw(4),
    paddingVertical: rh(1.2), borderRadius: 18,
  },
  bubbleMe: {
    backgroundColor: Colors.primary,
    borderBottomRightRadius: 4,
  },
  bubbleThem: {
    backgroundColor: Colors.white,
    borderBottomLeftRadius: 4,
    borderWidth: 1, borderColor: Colors.border,
  },
  bubbleTxt: { fontSize: RS.md, color: Colors.text, lineHeight: 20 },
  bubbleTxtMe: { color: Colors.white },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end',
    paddingHorizontal: rw(4), paddingVertical: rh(1.2),
    backgroundColor: Colors.white,
    borderTopWidth: 1, borderTopColor: Colors.border, gap: rw(3),
  },
  input: {
    flex: 1, backgroundColor: Colors.background,
    borderRadius: 24, paddingHorizontal: rw(4),
    paddingVertical: rh(1.2), fontSize: RS.md,
    color: Colors.text, maxHeight: rh(15),
    borderWidth: 1, borderColor: Colors.border,
  },
  sendBtn: {
    width: rw(12), height: rw(12), borderRadius: rw(6),
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
    elevation: 4, shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3, shadowRadius: 4,
  },
  sendBtnDisabled: { backgroundColor: Colors.lightGray, elevation: 0 },
  sendIcon: { color: Colors.white, fontSize: RS.md, fontWeight: '700' },
});