import {
  View, Text, StyleSheet, TextInput,
  FlatList, TouchableOpacity, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useEffect, useRef } from 'react';
import { router } from 'expo-router';
import { usePosts } from '../../context/PostContext';
import { useAuth } from '../../context/AuthContext';
import Colors from '../../constants/colors';
import { RS, rw, rh } from '../../constants/responsive';

const AVATAR_COLORS = [
  Colors.primary, Colors.secondary, Colors.teal,
  Colors.coral, Colors.accent, Colors.primaryDark,
];

function getColor(name) {
  const i = name ? name.charCodeAt(0) % AVATAR_COLORS.length : 0;
  return AVATAR_COLORS[i];
}

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

const TABS = ['All', 'Users', 'Posts'];

export default function Search() {
  const { posts } = usePosts();
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState('All');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState({ users: [], posts: [] });
  const [recentSearches, setRecentSearches] = useState([
    
  ]);
  const inputRef = useRef(null);
  const searchTimer = useRef(null);

  // Get unique users from posts
  const allUsers = posts.reduce((acc, post) => {
    if (!acc.find(u => u.userId === post.userId)) {
      acc.push({
        userId: post.userId,
        userName: post.userName,
        postCount: posts.filter(p => p.userId === post.userId).length,
      });
    }
    return acc;
  }, []);

  useEffect(() => {
    if (!query.trim()) {
      setResults({ users: [], posts: [] });
      setSearching(false);
      return;
    }

    // Debounce search
    setSearching(true);
    clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      performSearch(query.trim());
    }, 400);

    return () => clearTimeout(searchTimer.current);
  }, [query]);

  const performSearch = (q) => {
    const lower = q.toLowerCase();

    // Search users
    const matchedUsers = allUsers.filter(u =>
      u.userName.toLowerCase().includes(lower)
    );

    // Search posts by content or username
    const matchedPosts = posts.filter(p =>
      p.content.toLowerCase().includes(lower) ||
      p.userName.toLowerCase().includes(lower)
    );

    setResults({ users: matchedUsers, posts: matchedPosts });
    setSearching(false);
  };

  const handleSearch = (text) => {
    setQuery(text);
  };

  const handleClear = () => {
    setQuery('');
    setResults({ users: [], posts: [] });
    inputRef.current?.focus();
  };

  const handleRecentSearch = (term) => {
    setQuery(term);
  };

  const handleSubmit = () => {
    if (query.trim() && !recentSearches.includes(query.trim())) {
      setRecentSearches(prev => [query.trim(), ...prev.slice(0, 4)]);
    }
  };

  const openUserProfile = (userId, userName) => {
    if (userId === user?.id) {
      router.push('/(tabs)/profile');
    } else {
      router.push({
        pathname: '/(tabs)/user-profile',
        params: { userId, userName },
      });
    }
  };

  const totalResults = results.users.length + results.posts.length;

  const filteredUsers = activeTab === 'Posts' ? [] : results.users;
  const filteredPosts = activeTab === 'Users' ? [] : results.posts;

  const renderUser = (item) => {
    const color = getColor(item.userName);
    const isMe = item.userId === user?.id;
    return (
      <TouchableOpacity
        style={s.userCard}
        onPress={() => openUserProfile(item.userId, item.userName)}
        activeOpacity={0.7}
      >
        <View style={[s.userAvatar, { backgroundColor: color }]}>
          <Text style={s.userAvatarTxt}>{item.userName?.[0]?.toUpperCase()}</Text>
        </View>
        <View style={s.userInfo}>
          <View style={s.userNameRow}>
            <Text style={s.userName}>{item.userName}</Text>
            {isMe && (
              <View style={s.meBadge}>
                <Text style={s.meBadgeTxt}>You</Text>
              </View>
            )}
          </View>
          <Text style={s.userSub}>{item.postCount} {item.postCount === 1 ? 'post' : 'posts'}</Text>
        </View>
        <Text style={s.chevron}>›</Text>
      </TouchableOpacity>
    );
  };

  const renderPost = (item) => {
    const color = getColor(item.userName);
    // Highlight matching text
    const lower = query.toLowerCase();
    const contentIdx = item.content.toLowerCase().indexOf(lower);
    return (
      <TouchableOpacity
        style={s.postCard}
        onPress={() => openUserProfile(item.userId, item.userName)}
        activeOpacity={0.7}
      >
        <View style={[s.postAccent, { backgroundColor: color }]} />
        <View style={s.postBody}>
          <View style={s.postHeader}>
            <View style={[s.postAvatar, { backgroundColor: color }]}>
              <Text style={s.postAvatarTxt}>{item.userName?.[0]?.toUpperCase()}</Text>
            </View>
            <View>
              <Text style={s.postUserName}>{item.userName}</Text>
              <Text style={s.postTime}>{timeAgo(item.createdAt)}</Text>
            </View>
          </View>
          <Text style={s.postContent} numberOfLines={3}>
            {item.content}
          </Text>
          <View style={s.postStats}>
            <Text style={s.postStat}>❤️ {item.likes.length}</Text>
            <Text style={s.postStat}>💬 {item.comments.length}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={s.container}>

      {/* Header */}
      <View style={s.header}>
        <Text style={s.headerTitle}>Search</Text>
      </View>

      {/* Search Bar */}
      <View style={s.searchBarWrap}>
        <View style={s.searchBar}>
          <Text style={s.searchIcon}>🔍</Text>
          <TextInput
            ref={inputRef}
            style={s.searchInput}
            placeholder="Search users or posts..."
            placeholderTextColor={Colors.gray}
            value={query}
            onChangeText={handleSearch}
            onSubmitEditing={handleSubmit}
            returnKeyType="search"
            autoCorrect={false}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={handleClear} style={s.clearBtn}>
              <Text style={s.clearBtnTxt}>✕</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* No query — show recent searches and trending */}
      {!query.trim() ? (
        <FlatList
          data={[]}
          ListHeaderComponent={
            <View>
              {/* Recent Searches */}
              <View style={s.section}>
                <Text style={s.sectionTitle}>Recent Searches</Text>
                <View style={s.tagsWrap}>
                  {recentSearches.map((term, i) => (
                    <TouchableOpacity
                      key={i}
                      style={s.tag}
                      onPress={() => handleRecentSearch(term)}
                    >
                      <Text style={s.tagIcon}>🕐</Text>
                      <Text style={s.tagTxt}>{term}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {/* Trending Users */}
              <View style={s.section}>
                <Text style={s.sectionTitle}>People You May Know</Text>
                {allUsers.slice(0, 5).map(u => (
                  <View key={u.userId}>{renderUser(u)}</View>
                ))}
              </View>
            </View>
          }
          renderItem={null}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      ) : (
        <View style={{ flex: 1 }}>

          {/* Searching indicator */}
          {searching ? (
            <View style={s.loadingWrap}>
              <ActivityIndicator color={Colors.primary} size="small" />
              <Text style={s.loadingTxt}>Searching...</Text>
            </View>
          ) : (
            <View style={{ flex: 1 }}>

              {/* Results count */}
              <View style={s.resultsHeader}>
                <Text style={s.resultsTxt}>
                  {totalResults} result{totalResults !== 1 ? 's' : ''} for
                  <Text style={s.resultsQuery}> "{query}"</Text>
                </Text>
              </View>

              {/* Filter Tabs */}
              <View style={s.tabs}>
                {TABS.map(tab => (
                  <TouchableOpacity
                    key={tab}
                    style={[s.tab, activeTab === tab && s.tabActive]}
                    onPress={() => setActiveTab(tab)}
                    activeOpacity={0.7}
                  >
                    <Text style={[s.tabTxt, activeTab === tab && s.tabTxtActive]}>
                      {tab}
                      {tab === 'Users' && results.users.length > 0
                        ? ` (${results.users.length})`
                        : ''}
                      {tab === 'Posts' && results.posts.length > 0
                        ? ` (${results.posts.length})`
                        : ''}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Results */}
              {totalResults === 0 ? (
                <View style={s.emptyWrap}>
                  <Text style={s.emptyIcon}>🔍</Text>
                  <Text style={s.emptyTitle}>No results found</Text>
                  <Text style={s.emptyTxt}>
                    Try searching with different keywords
                  </Text>
                </View>
              ) : (
                <FlatList
                  data={[]}
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={{ paddingBottom: 100 }}
                  ListHeaderComponent={
                    <View>
                      {/* Users Section */}
                      {filteredUsers.length > 0 && (
                        <View style={s.section}>
                          <Text style={s.sectionTitle}>
                            👤 Users ({filteredUsers.length})
                          </Text>
                          {filteredUsers.map(u => (
                            <View key={u.userId}>{renderUser(u)}</View>
                          ))}
                        </View>
                      )}

                      {/* Posts Section */}
                      {filteredPosts.length > 0 && (
                        <View style={s.section}>
                          <Text style={s.sectionTitle}>
                            📝 Posts ({filteredPosts.length})
                          </Text>
                          {filteredPosts.map(p => (
                            <View key={p.id}>{renderPost(p)}</View>
                          ))}
                        </View>
                      )}
                    </View>
                  }
                  renderItem={null}
                />
              )}
            </View>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: rw(5), paddingVertical: rh(1.5),
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { fontSize: RS.xl, fontWeight: '800', color: Colors.primary },
  searchBarWrap: {
    paddingHorizontal: rw(4), paddingVertical: rh(1.5),
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.background, borderRadius: 14,
    paddingHorizontal: rw(4), paddingVertical: rh(1.2),
    borderWidth: 1.5, borderColor: Colors.border, gap: rw(2),
  },
  searchIcon: { fontSize: 16 },
  searchInput: {
    flex: 1, fontSize: RS.md,
    color: Colors.text, paddingVertical: 0,
  },
  clearBtn: {
    width: rw(6), height: rw(6), borderRadius: rw(3),
    backgroundColor: Colors.lightGray,
    justifyContent: 'center', alignItems: 'center',
  },
  clearBtnTxt: { fontSize: 10, color: Colors.gray, fontWeight: '700' },
  loadingWrap: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', paddingVertical: rh(3), gap: rw(2),
  },
  loadingTxt: { fontSize: RS.md, color: Colors.subText },
  resultsHeader: {
    paddingHorizontal: rw(5), paddingVertical: rh(1.2),
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  resultsTxt: { fontSize: RS.sm, color: Colors.subText },
  resultsQuery: { color: Colors.primary, fontWeight: '700' },
  tabs: {
    flexDirection: 'row', backgroundColor: Colors.white,
    paddingHorizontal: rw(4), paddingBottom: rh(1),
    borderBottomWidth: 1, borderBottomColor: Colors.border, gap: rw(2),
  },
  tab: {
    paddingHorizontal: rw(4), paddingVertical: rh(0.8),
    borderRadius: 20, borderWidth: 1.5, borderColor: Colors.border,
  },
  tabActive: {
    backgroundColor: Colors.primary, borderColor: Colors.primary,
  },
  tabTxt: { fontSize: RS.sm, color: Colors.subText, fontWeight: '600' },
  tabTxtActive: { color: Colors.white },
  section: { marginTop: rh(1.5), paddingHorizontal: rw(4) },
  sectionTitle: {
    fontSize: RS.sm, fontWeight: '700', color: Colors.subText,
    marginBottom: rh(1.2), textTransform: 'uppercase', letterSpacing: 0.5,
  },
  tagsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: rw(2) },
  tag: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.white, borderRadius: 20,
    paddingHorizontal: rw(4), paddingVertical: rh(0.8),
    borderWidth: 1, borderColor: Colors.border, gap: rw(1.5),
  },
  tagIcon: { fontSize: 12 },
  tagTxt: { fontSize: RS.sm, color: Colors.text, fontWeight: '500' },
  userCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.white, borderRadius: 14,
    padding: rw(4), marginBottom: rh(1),
    borderWidth: 1, borderColor: Colors.border,
    gap: rw(3), elevation: 1,
  },
  userAvatar: {
    width: rw(12), height: rw(12), borderRadius: rw(6),
    justifyContent: 'center', alignItems: 'center',
  },
  userAvatarTxt: { color: Colors.white, fontSize: RS.lg, fontWeight: '700' },
  userInfo: { flex: 1 },
  userNameRow: { flexDirection: 'row', alignItems: 'center', gap: rw(2) },
  userName: { fontSize: RS.md, fontWeight: '700', color: Colors.text },
  meBadge: {
    backgroundColor: Colors.primaryLight, borderRadius: 8,
    paddingHorizontal: rw(2), paddingVertical: 2,
  },
  meBadgeTxt: { fontSize: RS.xs, color: Colors.primary, fontWeight: '700' },
  userSub: { fontSize: RS.sm, color: Colors.subText, marginTop: 2 },
  chevron: { fontSize: 22, color: Colors.lightGray },
  postCard: {
    backgroundColor: Colors.white, borderRadius: 14,
    marginBottom: rh(1.2), borderWidth: 1,
    borderColor: Colors.border, overflow: 'hidden',
    elevation: 1,
  },
  postAccent: { height: 4 },
  postBody: { padding: rw(4) },
  postHeader: {
    flexDirection: 'row', alignItems: 'center',
    gap: rw(3), marginBottom: rh(1),
  },
  postAvatar: {
    width: rw(9), height: rw(9), borderRadius: rw(5),
    justifyContent: 'center', alignItems: 'center',
  },
  postAvatarTxt: { color: Colors.white, fontSize: RS.sm, fontWeight: '700' },
  postUserName: { fontSize: RS.sm, fontWeight: '700', color: Colors.text },
  postTime: { fontSize: RS.xs, color: Colors.subText },
  postContent: {
    fontSize: RS.md, color: Colors.text,
    lineHeight: 22, marginBottom: rh(1),
  },
  postStats: { flexDirection: 'row', gap: rw(3) },
  postStat: { fontSize: RS.sm, color: Colors.subText },
  emptyWrap: {
    alignItems: 'center', paddingTop: rh(8),
  },
  emptyIcon: { fontSize: 56, marginBottom: rh(1.5) },
  emptyTitle: { fontSize: RS.xl, fontWeight: '700', color: Colors.text, marginBottom: rh(0.8) },
  emptyTxt: { fontSize: RS.md, color: Colors.subText, textAlign: 'center' },
});