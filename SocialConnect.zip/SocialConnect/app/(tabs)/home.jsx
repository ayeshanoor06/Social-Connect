import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, RefreshControl, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useEffect } from 'react';
import { router } from 'expo-router';
import { usePosts } from '../../context/PostContext';
import { useAuth } from '../../context/AuthContext';
import PostCard from '../../components/PostCard';
import CommentModal from '../../components/CommentModal';
import Colors from '../../constants/colors';
import { SIZES, SHADOWS } from '../../constants/theme';
import { useFollow } from '../../context/FollowContext';




export default function Home() {
  const { posts, loadPostsForUser } = usePosts();
  const { user } = useAuth();

  const { loadFollowData } = useFollow();

useEffect(() => {
  if (user?.id) {
    loadPostsForUser(user.id);
    loadFollowData(user.id);
  }
}, [user?.id]);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [commentVisible, setCommentVisible] = useState(false);

  useEffect(() => {
    if (user?.id) {

    }
  }, [user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    await new Promise(r => setTimeout(r, 1000));
    setRefreshing(false);
  };

  const openComments = (post) => {
    setSelectedPost(post);
    setCommentVisible(true);
  };

  return (
    <SafeAreaView style={s.container}>

      {/* Header */}
      <View style={s.header}>
        <Text style={s.logo}>Social Connect</Text>
        <TouchableOpacity
          style={s.newPostBtn}
          onPress={() => router.push('/(tabs)/create-post')}
          activeOpacity={0.85}
        >
          <Text style={s.newPostTxt}>+ Post</Text>
        </TouchableOpacity>
      </View>

      {/* Stories / Welcome banner */}
      <View style={s.welcomeBanner}>
        <View style={s.welcomeAvatar}>
          <Text style={s.welcomeAvatarTxt}>{user?.name?.[0]?.toUpperCase()}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.welcomeName}>Hey, {user?.name?.split(' ')[0]}! 👋</Text>
          <Text style={s.welcomeSub}>What's happening today?</Text>
        </View>
        <TouchableOpacity
          style={s.writeBtn}
          onPress={() => router.push('/(tabs)/create-post')}
        >
          <Text style={s.writeBtnTxt}>Write...</Text>
        </TouchableOpacity>
      </View>

      {/* Feed */}
      <FlatList
        data={posts}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 100 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.primary]}
            tintColor={Colors.primary}
          />
        }
        ListEmptyComponent={
          <View style={s.emptyWrap}>
            <Text style={s.emptyIcon}>📭</Text>
            <Text style={s.emptyTitle}>No posts yet</Text>
            <Text style={s.emptyTxt}>Be the first one to post something!</Text>
            <TouchableOpacity
              style={s.emptyBtn}
              onPress={() => router.push('/(tabs)/create-post')}
            >
              <Text style={s.emptyBtnTxt}>Create Post</Text>
            </TouchableOpacity>
          </View>
        }
        renderItem={({ item }) => (
          <PostCard
            post={item}
            onCommentPress={openComments}
          />
        )}
      />

      {/* Comment Modal */}
      <CommentModal
        visible={commentVisible}
        post={selectedPost}
        onClose={() => {
          setCommentVisible(false);
          setSelectedPost(null);
        }}
      />

      {/* Floating Action Button */}
      <TouchableOpacity
        style={s.fab}
        onPress={() => router.push('/(tabs)/create-post')}
        activeOpacity={0.85}
      >
        <Text style={s.fabIcon}>✏️</Text>
      </TouchableOpacity>

    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', paddingHorizontal: 20, paddingVertical: 14,
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  logo: { fontSize: 20, fontWeight: '800', color: Colors.primary },
  newPostBtn: {
    backgroundColor: Colors.primary, borderRadius: 20,
    paddingVertical: 7, paddingHorizontal: 16,
  },
  newPostTxt: { color: Colors.white, fontWeight: '700', fontSize: SIZES.sm },
  welcomeBanner: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.white, paddingHorizontal: 16,
    paddingVertical: 12, gap: 10,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  welcomeAvatar: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  welcomeAvatarTxt: { color: Colors.white, fontWeight: '700', fontSize: 16 },
  welcomeName: { fontSize: SIZES.md, fontWeight: '700', color: Colors.text },
  welcomeSub: { fontSize: SIZES.xs, color: Colors.subText },
  writeBtn: {
    borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: 20, paddingVertical: 6, paddingHorizontal: 16,
    backgroundColor: Colors.background,
  },
  writeBtnTxt: { fontSize: SIZES.sm, color: Colors.gray },
  emptyWrap: { alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 60, marginBottom: 16 },
  emptyTitle: { fontSize: SIZES.xl, fontWeight: '700', color: Colors.text, marginBottom: 8 },
  emptyTxt: { fontSize: SIZES.md, color: Colors.subText, marginBottom: 24 },
  emptyBtn: {
    backgroundColor: Colors.primary, borderRadius: 12,
    paddingVertical: 12, paddingHorizontal: 32,
  },
  emptyBtnTxt: { color: Colors.white, fontWeight: '700', fontSize: SIZES.md },
  fab: {
    position: 'absolute', bottom: 90, right: 20,
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
    ...SHADOWS.button,
  },
  fabIcon: { fontSize: 22 },
});