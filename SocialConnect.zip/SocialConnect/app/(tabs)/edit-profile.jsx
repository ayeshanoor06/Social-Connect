import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, ActivityIndicator,
  Image, Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import Colors from '../../constants/colors';
import { SIZES, SHADOWS } from '../../constants/theme';

export default function EditProfile() {
  const { user, updateProfile } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatar, setAvatar] = useState(user?.avatar || null);
  const [loading, setLoading] = useState(false);

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Permission needed', 'Please allow access to your photo library.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (!result.canceled) {
      setAvatar(result.assets[0].uri);
    }
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Name cannot be empty');
      return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    updateProfile({ name: name.trim(), bio: bio.trim(), avatar });
    setLoading(false);
    Alert.alert('Success', 'Profile updated!', [
      { text: 'OK', onPress: () => router.back() }
    ]);
  };

  return (
    <SafeAreaView style={s.container}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={s.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={s.backBtn}>← Back</Text>
          </TouchableOpacity>
          <Text style={s.headerTitle}>Edit Profile</Text>
          <View style={{ width: 60 }} />
        </View>

        {/* Avatar Picker */}
        <View style={s.avatarSection}>
          <TouchableOpacity onPress={pickImage} activeOpacity={0.8}>
            {avatar ? (
              <Image source={{ uri: avatar }} style={s.avatarImg} />
            ) : (
              <View style={s.avatarPlaceholder}>
                <Text style={s.avatarInitial}>{name?.[0]?.toUpperCase() || 'U'}</Text>
              </View>
            )}
            <View style={s.cameraBtn}>
              <Text style={{ fontSize: 16 }}>📷</Text>
            </View>
          </TouchableOpacity>
          <Text style={s.changePhotoTxt}>Tap to change photo</Text>
        </View>

        {/* Form */}
        <View style={s.card}>
          <View style={s.fieldGroup}>
            <Text style={s.label}>Full Name</Text>
            <TextInput
              style={s.input}
              value={name}
              onChangeText={setName}
              placeholder="Your full name"
              placeholderTextColor={Colors.gray}
              autoCapitalize="words"
            />
          </View>

          <View style={s.fieldGroup}>
            <Text style={s.label}>Bio</Text>
            <TextInput
              style={[s.input, s.bioInput]}
              value={bio}
              onChangeText={setBio}
              placeholder="Tell people about yourself..."
              placeholderTextColor={Colors.gray}
              multiline
              numberOfLines={4}
              maxLength={150}
            />
            <Text style={s.charCount}>{bio.length}/150</Text>
          </View>

          <View style={s.fieldGroup}>
            <Text style={s.label}>Email</Text>
            <TextInput
              style={[s.input, s.disabledInput]}
              value={user?.email}
              editable={false}
            />
            <Text style={s.hintTxt}>Email cannot be changed</Text>
          </View>
        </View>

        {/* Save Button */}
        <TouchableOpacity
          style={[s.saveBtn, loading && { opacity: 0.75 }]}
          onPress={handleSave}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading
            ? <ActivityIndicator color={Colors.white} />
            : <Text style={s.saveBtnTxt}>Save Changes</Text>
          }
        </TouchableOpacity>

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtn: { color: Colors.primary, fontSize: SIZES.md, fontWeight: '600' },
  headerTitle: { fontSize: SIZES.lg, fontWeight: '700', color: Colors.text },
  avatarSection: { alignItems: 'center', paddingVertical: 32 },
  avatarImg: {
    width: 100, height: 100, borderRadius: 50,
    borderWidth: 3, borderColor: Colors.primary,
  },
  avatarPlaceholder: {
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 3, borderColor: Colors.primaryLight,
  },
  avatarInitial: { fontSize: 38, fontWeight: '700', color: Colors.white },
  cameraBtn: {
    position: 'absolute', bottom: 0, right: 0,
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: Colors.white,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1.5, borderColor: Colors.border,
    ...SHADOWS.card,
  },
  changePhotoTxt: { color: Colors.primary, fontSize: SIZES.sm, fontWeight: '600', marginTop: 10 },
  card: {
    backgroundColor: Colors.white, borderRadius: SIZES.radiusLg,
    marginHorizontal: 20, padding: 24,
    marginBottom: 20, ...SHADOWS.card,
  },
  fieldGroup: { marginBottom: 20 },
  label: { fontSize: SIZES.sm, fontWeight: '600', color: Colors.text, marginBottom: 8 },
  input: {
    backgroundColor: Colors.inputBg, borderWidth: 1.5,
    borderColor: Colors.border, borderRadius: SIZES.radius,
    paddingHorizontal: 16, paddingVertical: 13,
    fontSize: SIZES.base, color: Colors.text,
  },
  bioInput: { height: 100, textAlignVertical: 'top', paddingTop: 13 },
  disabledInput: { backgroundColor: Colors.lightGray, color: Colors.gray },
  charCount: { fontSize: SIZES.xs, color: Colors.gray, textAlign: 'right', marginTop: 4 },
  hintTxt: { fontSize: SIZES.xs, color: Colors.gray, marginTop: 4 },
  saveBtn: {
    backgroundColor: Colors.primary, borderRadius: SIZES.radius,
    paddingVertical: 16, marginHorizontal: 20,
    alignItems: 'center', marginBottom: 40, ...SHADOWS.button,
  },
  saveBtnTxt: { color: Colors.white, fontSize: SIZES.base, fontWeight: '700' },
});