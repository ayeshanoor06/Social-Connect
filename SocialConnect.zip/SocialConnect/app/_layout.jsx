import { Stack } from 'expo-router';
import { LogBox } from 'react-native';
import { useEffect, useRef } from 'react';
import { AuthProvider, useAuth } from '../context/AuthContext';
import { PostProvider } from '../context/PostContext';
import { FollowProvider } from '../context/FollowContext';
import { MessageProvider } from '../context/MessageContext';
import { View, ActivityIndicator } from 'react-native';
import * as Notifications from 'expo-notifications';
import Colors from '../constants/colors';
import { registerForNotifications } from '../utils/notifications';

LogBox.ignoreLogs(['expo-notifications']);

function RootNavigator() {
  const { appReady } = useAuth();
  const notifListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    registerForNotifications();
    notifListener.current = Notifications.addNotificationReceivedListener(n => {
      console.log('Notification received:', n);
    });
    responseListener.current = Notifications.addNotificationResponseReceivedListener(r => {
      console.log('Notification tapped:', r);
    });
    return () => {
      if (notifListener.current)
        Notifications.removeNotificationSubscription(notifListener.current);
      if (responseListener.current)
        Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);

  if (!appReady) {
    return (
      <View style={{
        flex: 1, justifyContent: 'center',
        alignItems: 'center', backgroundColor: Colors.primary,
      }}>
        <ActivityIndicator color={Colors.white} size="large" />
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="splash" options={{ animation: 'none' }} />
      <Stack.Screen name="index" options={{ animation: 'none' }} />
      <Stack.Screen name="(auth)" />
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <AuthProvider>
      <PostProvider>
        <FollowProvider>
          <MessageProvider>
            <RootNavigator />
          </MessageProvider>
        </FollowProvider>
      </PostProvider>
    </AuthProvider>
  );
}