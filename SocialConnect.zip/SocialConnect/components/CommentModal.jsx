import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Modal, TouchableOpacity,
  FlatList, TextInput, KeyboardAvoidingView,
  Platform, ActivityIndicator
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { notifyCommented } from '../utils/notifications';
import Colors from '../constants/colors';

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function CommentModal({ visible, post, onClose }) {
  const { user } = useAuth();
  const { posts, addComment } = usePosts();
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);

  if (!post) return null;

  const livePost = posts.find(p => p.id === post.id);
  const comments = livePost ? livePost.comments : [];

  const handleSend = async () => {
    if (!text.trim()) return;
    setSending(true);
    const commentText = text.trim();
    setText('');
    await addComment(post.id, {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      text: commentText,
      createdAt: new Date().toISOString(),
    });
    if (post.userId !== user.id) {
      await notifyCommented(post.userName, user.name, commentText);
    }
    setSending(false);
  };

  const renderComment = ({ item }) => (
    <View style={s.commentItem}>
      <View style={s.commentAvatar}>
        <Text style={s.commentAvatarTxt}>
          {item.userName ? item.userName[0].toUpperCase() : '?'}
        </Text>
      </View>
      <View style={s.commentBody}>
        <View style={s.commentBubble}>
          <Text style={s.commentUser}>{item.userName}</Text>
          <Text style={s.commentText}>{item.text}</Text>
        </View>
        <Text style={s.commentTime}>{timeAgo(item.createdAt)}</Text>
      </View>
    </View>
  );

  const renderEmpty = () => (
    <View style={s.emptyWrap}>
      <Text style={s.emptyIcon}>💬</Text>
      <Text style={s.emptyTxt}>No comments yet. Be the first!</Text>
    </View>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={s.overlay}>
        <KeyboardAvoidingView
          style={s.sheet}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={s.handle} />

          <View style={s.titleRow}>
            <Text style={s.title}>Comments ({comments.length})</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Text style={s.closeBtn}>✕</Text>
            </TouchableOpacity>
          </View>

          <View style={s.postPreview}>
            <Text style={s.previewTxt} numberOfLines={2}>
              {post.content}
            </Text>
          </View>

          <FlatList
            data={comments}
            keyExtractor={(item) => item.id}
            style={s.list}
            contentContainerStyle={s.listContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={renderEmpty}
            renderItem={renderComment}
          />

          <View style={s.inputRow}>
            <View style={s.myAvatar}>
              <Text style={s.myAvatarTxt}>
                {user && user.name ? user.name[0].toUpperCase() : '?'}
              </Text>
            </View>
            <TextInput
              style={s.input}
              value={text}
              onChangeText={setText}
              placeholder="Write a comment..."
              placeholderTextColor={Colors.gray}
              multiline={true}
              maxLength={300}
            />
            <TouchableOpacity
              style={[s.sendBtn, (!text.trim() || sending) && s.sendBtnDisabled]}
              onPress={handleSend}
              disabled={!text.trim() || sending}
            >
              {sending
                ? <ActivityIndicator color={Colors.white} size="small" />
                : <Text style={s.sendIcon}>➤</Text>
              }
            </TouchableOpacity>
          </View>

        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(76, 63, 153, 0.5)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '85%',
    minHeight: 300,
    paddingBottom: 20,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.lightGray,
    alignSelf: 'center',
    marginTop: 12,
    marginBottom: 8,
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.text,
  },
  closeBtn: {
    fontSize: 18,
    color: Colors.gray,
    fontWeight: '600',
  },
  postPreview: {
    backgroundColor: Colors.background,
    marginHorizontal: 16,
    marginTop: 12,
    padding: 12,
    borderRadius: 12,
    borderLeftWidth: 3,
    borderLeftColor: Colors.primary,
  },
  previewTxt: {
    fontSize: 13,
    color: Colors.subText,
    lineHeight: 20,
  },
  list: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
    flexGrow: 1,
  },
  emptyWrap: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIcon: {
    fontSize: 40,
    marginBottom: 8,
  },
  emptyTxt: {
    fontSize: 14,
    color: Colors.subText,
  },
  commentItem: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  commentAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  commentAvatarTxt: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '700',
  },
  commentBody: {
    flex: 1,
  },
  commentBubble: {
    backgroundColor: Colors.background,
    borderRadius: 12,
    padding: 10,
    marginBottom: 4,
  },
  commentUser: {
    fontSize: 13,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 2,
  },
  commentText: {
    fontSize: 14,
    color: Colors.text,
    lineHeight: 20,
  },
  commentTime: {
    fontSize: 11,
    color: Colors.subText,
    marginLeft: 4,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    gap: 8,
  },
  myAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  myAvatarTxt: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '700',
  },
  input: {
    flex: 1,
    backgroundColor: Colors.background,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 14,
    color: Colors.text,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtnDisabled: {
    backgroundColor: Colors.lightGray,
  },
  sendIcon: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '700',
  },
});