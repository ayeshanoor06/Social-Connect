import {
  View, Text, StyleSheet, TouchableOpacity,
  Image, Animated, Alert, Modal, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator
} from 'react-native';
import { useState, useRef } from 'react';
import { router } from 'expo-router';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { notifyLiked, notifyUnliked } from '../utils/notifications';
import Colors from '../constants/colors';
import { RS, rw, rh } from '../constants/responsive';

const AVATAR_COLORS = [
  Colors.primary, Colors.secondary, Colors.teal,
  Colors.coral, Colors.accent, Colors.primaryDark,
];

function getColor(name) {
  const i = name ? name.charCodeAt(0) % AVATAR_COLORS.length : 0;
  return AVATAR_COLORS[i];
}

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function PostCard({ post, onCommentPress }) {
  const { user } = useAuth();
  const { toggleLike, deletePost, editPost } = usePosts();
  const liked = post.likes.includes(user?.id);
  const [imgError, setImgError] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [editVisible, setEditVisible] = useState(false);
  const [editText, setEditText] = useState(post.content);
  const [editLoading, setEditLoading] = useState(false);
  const avatarColor = getColor(post.userName);
  const isOwnPost = post.userId === user?.id;

  const likeScale = useRef(new Animated.Value(1)).current;
  const heartOpacity = useRef(new Animated.Value(0)).current;
  const heartScale = useRef(new Animated.Value(0)).current;

  const handleLike = async () => {
    Animated.sequence([
      Animated.spring(likeScale, {
        toValue: 1.4, useNativeDriver: true, speed: 50, bounciness: 10,
      }),
      Animated.spring(likeScale, {
        toValue: 1, useNativeDriver: true, speed: 50,
      }),
    ]).start();

    if (!liked) {
      heartOpacity.setValue(1);
      heartScale.setValue(0);
      Animated.sequence([
        Animated.spring(heartScale, {
          toValue: 1.5, useNativeDriver: true, speed: 20, bounciness: 15,
        }),
        Animated.timing(heartScale, {
          toValue: 1, duration: 100, useNativeDriver: true,
        }),
      ]).start();
      setTimeout(() => {
        Animated.timing(heartOpacity, {
          toValue: 0, duration: 400, useNativeDriver: true,
        }).start();
      }, 600);
      if (!isOwnPost) await notifyLiked(post.userName, user?.name);
    } else {
      if (!isOwnPost) await notifyUnliked(post.userName, user?.name);
    }
    toggleLike(post.id, user?.id);
  };

  const handleUserPress = () => {
    if (isOwnPost) {
      router.push('/(tabs)/profile');
    } else {
      router.push({
        pathname: '/(tabs)/user-profile',
        params: { userId: post.userId, userName: post.userName },
      });
    }
  };

  const handleDelete = () => {
    setMenuVisible(false);
    Alert.alert(
      '🗑️ Delete Post',
      'Are you sure you want to delete this post? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => deletePost(post.id, user?.id),
        },
      ]
    );
  };

  const handleEditOpen = () => {
    setEditText(post.content);
    setMenuVisible(false);
    setEditVisible(true);
  };

  const handleEditSave = async () => {
    if (!editText.trim()) {
      Alert.alert('Error', 'Post content cannot be empty.');
      return;
    }
    if (editText.trim() === post.content) {
      setEditVisible(false);
      return;
    }
    setEditLoading(true);
    await editPost(post.id, editText.trim(), user?.id);
    setEditLoading(false);
    setEditVisible(false);
  };

  return (
    <View style={s.card}>
      <View style={[s.cardAccent, { backgroundColor: avatarColor }]} />

      <Animated.Text style={[s.floatingHeart, {
        opacity: heartOpacity,
        transform: [{ scale: heartScale }],
      }]}>
        ❤️
      </Animated.Text>

      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity
          style={s.userRow}
          onPress={handleUserPress}
          activeOpacity={0.7}
        >
          <View style={[s.avatar, { backgroundColor: avatarColor }]}>
            <Text style={s.avatarTxt}>{post.userName?.[0]?.toUpperCase()}</Text>
          </View>
          <View style={s.userInfo}>
            <View style={s.nameRow}>
              <Text style={s.userName}>{post.userName}</Text>
              {isOwnPost && <Text style={s.youBadge}> (You)</Text>}
              {post.edited && <Text style={s.editedBadge}> · edited</Text>}
            </View>
            <Text style={s.time}>{timeAgo(post.createdAt)}</Text>
          </View>
        </TouchableOpacity>

        {/* Three dot menu — only own posts */}
        {isOwnPost && (
          <View>
            <TouchableOpacity
              style={s.menuBtn}
              onPress={() => setMenuVisible(!menuVisible)}
              activeOpacity={0.7}
            >
              <Text style={s.menuDots}>⋮</Text>
            </TouchableOpacity>

            {menuVisible && (
              <View style={s.menuDropdown}>
                {/* Edit Option */}
                <TouchableOpacity
                  style={s.menuItem}
                  onPress={handleEditOpen}
                >
                  <Text style={s.menuIcon}>✏️</Text>
                  <Text style={s.menuEditTxt}>Edit Post</Text>
                </TouchableOpacity>

                <View style={s.menuDivider} />

                {/* Delete Option */}
                <TouchableOpacity
                  style={s.menuItem}
                  onPress={handleDelete}
                >
                  <Text style={s.menuIcon}>🗑️</Text>
                  <Text style={s.menuDeleteTxt}>Delete Post</Text>
                </TouchableOpacity>

                <View style={s.menuDivider} />

                {/* Cancel */}
                <TouchableOpacity
                  style={[s.menuItem, { borderBottomWidth: 0 }]}
                  onPress={() => setMenuVisible(false)}
                >
                  <Text style={s.menuIcon}>✕</Text>
                  <Text style={s.menuCancelTxt}>Cancel</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
      </View>

      {/* Content */}
      <Text style={s.content}>{post.content}</Text>

      {/* Image */}
      {post.image && !imgError && (
        <Image
          source={{ uri: post.image }}
          style={s.postImg}
          resizeMode="cover"
          onError={() => setImgError(true)}
        />
      )}

      {/* Actions */}
      <View style={s.actions}>
        <TouchableOpacity
          style={s.actionBtn}
          onPress={handleLike}
          activeOpacity={0.7}
        >
          <Animated.Text style={[s.actionIcon, {
            transform: [{ scale: likeScale }],
          }]}>
            {liked ? '❤️' : '🤍'}
          </Animated.Text>
          <Text style={[s.actionTxt, liked && s.likedTxt]}>
            {post.likes.length} {post.likes.length === 1 ? 'Like' : 'Likes'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={s.actionBtn}
          onPress={() => onCommentPress(post)}
          activeOpacity={0.7}
        >
          <Text style={s.actionIcon}>💬</Text>
          <Text style={s.actionTxt}>
            {post.comments.length} {post.comments.length === 1 ? 'Comment' : 'Comments'}
          </Text>
        </TouchableOpacity>

        <View style={{ flex: 1 }} />
        <View style={[s.likeBadge, liked && s.likeBadgeActive]}>
          <Text style={[s.likeBadgeTxt, liked && s.likeBadgeTxtActive]}>
            {liked ? '❤️ Liked' : 'Like'}
          </Text>
        </View>
      </View>

      {/* Edit Modal */}
      <Modal
        visible={editVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEditVisible(false)}
      >
        <KeyboardAvoidingView
          style={s.modalOverlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={s.editModal}>

            {/* Modal Header */}
            <View style={s.editModalHeader}>
              <TouchableOpacity onPress={() => setEditVisible(false)}>
                <Text style={s.editCancelBtn}>Cancel</Text>
              </TouchableOpacity>
              <Text style={s.editModalTitle}>Edit Post</Text>
              <TouchableOpacity
                onPress={handleEditSave}
                disabled={editLoading || !editText.trim()}
              >
                {editLoading
                  ? <ActivityIndicator color={Colors.primary} size="small" />
                  : <Text style={[
                      s.editSaveBtn,
                      !editText.trim() && { opacity: 0.4 },
                    ]}>
                      Save
                    </Text>
                }
              </TouchableOpacity>
            </View>

            {/* User Row */}
            <View style={s.editUserRow}>
              <View style={[s.editAvatar, { backgroundColor: avatarColor }]}>
                <Text style={s.editAvatarTxt}>
                  {user?.name?.[0]?.toUpperCase()}
                </Text>
              </View>
              <Text style={s.editUserName}>{user?.name}</Text>
            </View>

            {/* Text Input */}
            <TextInput
              style={s.editInput}
              value={editText}
              onChangeText={setEditText}
              multiline
              autoFocus
              maxLength={500}
              placeholder="What's on your mind?"
              placeholderTextColor={Colors.gray}
            />

            <Text style={s.editCharCount}>{editText.length}/500</Text>

            {/* Save Button */}
            <TouchableOpacity
              style={[
                s.editSaveBtnFull,
                (!editText.trim() || editLoading) && { opacity: 0.6 },
              ]}
              onPress={handleEditSave}
              disabled={!editText.trim() || editLoading}
              activeOpacity={0.85}
            >
              {editLoading
                ? <ActivityIndicator color={Colors.white} />
                : <Text style={s.editSaveBtnTxt}>Save Changes</Text>
              }
            </TouchableOpacity>

          </View>
        </KeyboardAvoidingView>
      </Modal>

    </View>
  );
}

const s = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    borderRadius: 18, marginHorizontal: rw(4),
    marginBottom: rh(1.5), overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border,
    elevation: 2, shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 8,
  },
  cardAccent: { height: 4, width: '100%' },
  floatingHeart: {
    position: 'absolute', fontSize: 60,
    alignSelf: 'center', top: '30%', zIndex: 99,
  },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingRight: rw(3), paddingTop: rw(2),
  },
  userRow: {
    flex: 1, flexDirection: 'row',
    alignItems: 'center', padding: rw(4), paddingBottom: rw(2),
  },
  avatar: {
    width: rw(11), height: rw(11), borderRadius: rw(6),
    justifyContent: 'center', alignItems: 'center', marginRight: rw(3),
  },
  avatarTxt: { color: Colors.white, fontSize: RS.md, fontWeight: '700' },
  userInfo: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  userName: { fontSize: RS.md, fontWeight: '700', color: Colors.text },
  youBadge: { fontSize: RS.xs, color: Colors.subText, fontWeight: '400' },
  editedBadge: { fontSize: RS.xs, color: Colors.gray, fontStyle: 'italic' },
  time: { fontSize: RS.xs, color: Colors.subText, marginTop: 1 },
  menuBtn: {
    width: rw(10), height: rw(10),
    justifyContent: 'center', alignItems: 'center',
    borderRadius: rw(5),
  },
  menuDots: { fontSize: 22, color: Colors.gray, fontWeight: '700' },
  menuDropdown: {
    position: 'absolute', right: 0, top: rw(10),
    backgroundColor: Colors.white, borderRadius: 14,
    borderWidth: 1, borderColor: Colors.border,
    zIndex: 999, minWidth: rw(42),
    elevation: 12, shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15, shadowRadius: 8,
  },
  menuItem: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: rw(4), paddingVertical: rh(1.5), gap: rw(3),
  },
  menuDivider: { height: 1, backgroundColor: Colors.border },
  menuIcon: { fontSize: 16, width: 22 },
  menuEditTxt: { fontSize: RS.md, color: Colors.primary, fontWeight: '600' },
  menuDeleteTxt: { fontSize: RS.md, color: Colors.error, fontWeight: '600' },
  menuCancelTxt: { fontSize: RS.md, color: Colors.gray, fontWeight: '500' },
  content: {
    fontSize: RS.md, color: Colors.text,
    lineHeight: 22, paddingHorizontal: rw(4), paddingBottom: rw(3),
  },
  postImg: { width: '100%', height: rh(28), marginBottom: rw(3) },
  actions: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: rw(4), paddingVertical: rh(1.2),
    borderTopWidth: 1, borderTopColor: Colors.border, gap: rw(4),
  },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  actionIcon: { fontSize: 18 },
  actionTxt: { fontSize: RS.sm, color: Colors.subText, fontWeight: '500' },
  likedTxt: { color: Colors.secondary, fontWeight: '700' },
  likeBadge: {
    paddingHorizontal: rw(3), paddingVertical: rh(0.4),
    borderRadius: 20, borderWidth: 1, borderColor: Colors.border,
  },
  likeBadgeActive: {
    backgroundColor: Colors.secondaryLight, borderColor: Colors.secondary,
  },
  likeBadgeTxt: { fontSize: RS.xs, color: Colors.gray, fontWeight: '600' },
  likeBadgeTxtActive: { color: Colors.secondary },

  // Edit Modal
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  editModal: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    paddingBottom: rh(4), maxHeight: '90%',
  },
  editModalHeader: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: rw(5), paddingVertical: rh(2),
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  editModalTitle: { fontSize: RS.lg, fontWeight: '700', color: Colors.text },
  editCancelBtn: { fontSize: RS.md, color: Colors.gray, fontWeight: '500' },
  editSaveBtn: { fontSize: RS.md, color: Colors.primary, fontWeight: '700' },
  editUserRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: rw(5), paddingVertical: rh(1.5), gap: rw(3),
  },
  editAvatar: {
    width: rw(10), height: rw(10), borderRadius: rw(5),
    justifyContent: 'center', alignItems: 'center',
  },
  editAvatarTxt: { color: Colors.white, fontSize: RS.md, fontWeight: '700' },
  editUserName: { fontSize: RS.md, fontWeight: '700', color: Colors.text },
  editInput: {
    fontSize: 17, color: Colors.text,
    paddingHorizontal: rw(5), minHeight: rh(15),
    textAlignVertical: 'top', lineHeight: 26,
  },
  editCharCount: {
    fontSize: RS.xs, color: Colors.gray,
    textAlign: 'right', marginRight: rw(5), marginBottom: rh(2),
  },
  editSaveBtnFull: {
    backgroundColor: Colors.primary, borderRadius: 14,
    paddingVertical: rh(1.8), marginHorizontal: rw(5),
    alignItems: 'center', elevation: 4,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3, shadowRadius: 6,
  },
  editSaveBtnTxt: { color: Colors.white, fontWeight: '700', fontSize: RS.md },
});